// Sammati Expo config plugin.
//
// Add it once in app.json / app.config.js:
//   { "expo": { "plugins": ["@sammati/react-native"] } }
//
// On `expo prebuild` it wires up the native SDKs the RN bridge depends on, so
// `pod install` and the Gradle sync resolve them without the customer editing
// Podfile / settings.gradle by hand:
//   • iOS     — injects the published `Sammati` pod into the Podfile (satisfies
//               the bridge's transitive `s.dependency 'Sammati'`).
//   • Android — adds the published Maven repo so `io.sammati:sdk-android` resolves.
//
// Bare (non-Expo) RN apps don't run prebuild — they add the same two lines
// manually; see the README.
const { withDangerousMod } = require('@expo/config-plugins');
const fs = require('node:fs');
const path = require('node:path');
const { addSammatiPod, addSammatiMaven } = require('./plugin/edits.js');

const withSammatiPod = (config) =>
  withDangerousMod(config, [
    'ios',
    (cfg) => {
      const podfile = path.join(cfg.modRequest.platformProjectRoot, 'Podfile');
      if (fs.existsSync(podfile)) {
        fs.writeFileSync(podfile, addSammatiPod(fs.readFileSync(podfile, 'utf8')));
      }
      return cfg;
    },
  ]);

const withSammatiMaven = (config) =>
  withDangerousMod(config, [
    'android',
    (cfg) => {
      const root = cfg.modRequest.platformProjectRoot;
      for (const [name, kotlin] of [['settings.gradle.kts', true], ['settings.gradle', false]]) {
        const file = path.join(root, name);
        if (fs.existsSync(file)) {
          fs.writeFileSync(file, addSammatiMaven(fs.readFileSync(file, 'utf8'), kotlin));
          break;
        }
      }
      return cfg;
    },
  ]);

module.exports = (config) => withSammatiMaven(withSammatiPod(config));
