// React Native autolinking config (RN ≥ 0.60). Tells the host app's
// native build to pick up our iOS pod + Android Gradle module without
// the customer having to edit Podfile / settings.gradle by hand.
module.exports = {
  dependency: {
    platforms: {
      ios: {
        podspecPath: __dirname + '/Sammati.podspec',
      },
      android: {
        sourceDir: __dirname + '/android',
        packageImportPath: 'import io.sammati.sdk.reactnative.SammatiRNPackage;',
        packageInstance: 'new SammatiRNPackage()',
      },
    },
  },
};
