import { describe, it, expect } from 'vitest';
// @ts-expect-error — plain-JS plugin helper, no type declarations
import edits from '../../plugin/edits.js';

const { addSammatiPod, addSammatiMaven, SAMMATI_PODSPEC_URL, SAMMATI_MAVEN_URL } = edits;

describe('addSammatiPod', () => {
  const podfile =
    `platform :ios, '14.0'\n\ntarget 'TantuPratha' do\n  use_expo_modules!\nend\n`;

  it('injects the Sammati pod inside the app target (happy path)', () => {
    const out = addSammatiPod(podfile);
    expect(out).toContain(`pod 'Sammati', :podspec => '${SAMMATI_PODSPEC_URL}'`);
    // must land AFTER the target line, not before it
    expect(out.indexOf("pod 'Sammati'")).toBeGreaterThan(out.indexOf("target 'TantuPratha' do"));
  });

  it('is idempotent — does not inject a second time', () => {
    const once = addSammatiPod(podfile);
    expect(addSammatiPod(once)).toBe(once);
  });

  it('returns the Podfile unchanged when there is no target block', () => {
    const noTarget = `platform :ios, '14.0'\n`;
    expect(addSammatiPod(noTarget)).toBe(noTarget);
  });
});

describe('addSammatiMaven', () => {
  const kts =
    `dependencyResolutionManagement {\n  repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)\n  repositories {\n    google()\n    mavenCentral()\n  }\n}\n`;

  it('adds the Maven repo to dependencyResolutionManagement (Kotlin DSL)', () => {
    const out = addSammatiMaven(kts, true);
    expect(out).toContain(`maven { url = uri("${SAMMATI_MAVEN_URL}") }`);
  });

  it('uses Groovy syntax when kotlin=false', () => {
    const groovy =
      `dependencyResolutionManagement {\n  repositories {\n    google()\n  }\n}\n`;
    const out = addSammatiMaven(groovy, false);
    expect(out).toContain(`maven { url '${SAMMATI_MAVEN_URL}' }`);
  });

  it('is idempotent and no-ops without a dependencyResolutionManagement block', () => {
    const once = addSammatiMaven(kts, true);
    expect(addSammatiMaven(once, true)).toBe(once);
    const noBlock = `pluginManagement { repositories { google() } }\n`;
    expect(addSammatiMaven(noBlock, true)).toBe(noBlock);
  });
});
