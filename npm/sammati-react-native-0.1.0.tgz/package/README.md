# @sammati/react-native — Sammati consent SDK for React Native

A thin React Native bridge over the Sammati [iOS](../sdk-ios/) and
[Android](../sdk-android/) native SDKs. Drop it into a React Native app
and you get a DPDP-compliant consent banner, hosted preference centre,
offline-tolerant consent writes, and the same M1 ledger artifact shape
as a bare-native integration.

## Why a bridge (not a JavaScript re-implementation)

The banner UI, locale resolution, persistence and offline queue all live
in the native SDKs. The bridge is intentionally a few hundred lines of
glue — no JS port of those concerns. That protects the UX-compliance
invariant: a customer using bare iOS, bare Android, React Native, or
Capacitor sees the **same** banner behavior on the same OS, and the M1
ledger artifact shape is identical across all four host platforms.

## Install

```bash
npm install @sammati/react-native
# or
pnpm add @sammati/react-native
# or
yarn add @sammati/react-native
```

Then on iOS:

```bash
cd ios && pod install
```

That's it for RN ≥ 0.60 — autolinking picks up the package via the
[react-native.config.js](./react-native.config.js) at the package root.

## Integrate (3 lines)

```tsx
import { useEffect } from 'react';
import { AppState } from 'react-native';
import { Sammati } from '@sammati/react-native';

// 1. Configure once at app startup.
Sammati.configure({ tenantId: 'ten_xxxxxxxxxxxx' });

export function App() {
  // 2. Show the banner if no choices exist for the current notice.
  useEffect(() => {
    Sammati.showBannerIfNeeded();
  }, []);

  // 3. Drain the offline queue when the app foregrounds.
  useEffect(() => {
    const sub = AppState.addEventListener('change', (s) => {
      if (s === 'active') Sammati.flushOfflineQueue();
    });
    return () => sub.remove();
  }, []);

  return <YourApp />;
}
```

The rest of the surface mirrors the native SDKs:

| Method | What it does |
|---|---|
| `Sammati.configure({ tenantId, baseURL? })` | One-shot init — `tenantId` validated synchronously |
| `Sammati.showBannerIfNeeded()` | Native modal sheet; no-op if already consented |
| `Sammati.openPreferenceCenter({ returnUrl? })` | SFSafariViewController / Chrome Custom Tab — never a WebView |
| `Sammati.setLocale(locale \| null)` | Override OS locale; `null` reverts to the fallback chain |
| `Sammati.getChoices(): Promise<Record<string, boolean> \| null>` | Current choices; `null` on clean install |
| `Sammati.withdraw()` | Clears choices; next `showBannerIfNeeded()` re-renders |
| `Sammati.reset()` | Wipes all SDK state — QA / sign-out only |
| `Sammati.flushOfflineQueue()` | Drain queued consent writes — idempotent |
| `Sammati.getQueueDepth(): Promise<number>` | Unflushed write count — useful for QA badges |

## Local testing with a self-hosted core-api

Pass `baseURL` to `configure()`:

```ts
Sammati.configure({
  tenantId: 'ten_xxxxxxxxxxxx',
  // Android emulator routes host's localhost via 10.0.2.2.
  // iOS simulator can use localhost directly.
  baseURL: 'http://10.0.2.2:8000',
});
```

See [documentation/mobile/testing/](../../documentation/mobile/testing/)
for the full local-loop guide — Docker stack, tenant seeding, network
security config, ATS opt-in, M1 ledger verification.

## What this package does NOT do

- **No JavaScript re-implementation** of locale resolution, persistence,
  or the offline queue. Those live in the native SDKs by design.
- **No API key on device.** The bridge talks only to the public
  unauthenticated routes (`/v1/banner/public/*`, `/v1/mobile-config/*`).
  Server-side security is bundle-id allowlist (MOB-09) + (optional)
  attestation.
- **No Expo Go support.** Expo Go cannot load native code, so the
  bridge requires a custom dev client or a bare RN project. Expo bare
  workflow and `expo prebuild` both work.

## Compatibility

| | Min version |
|---|---|
| React Native | 0.71 |
| iOS | 14.0 |
| Android | API 24 (Android 7.0) |
| React | 18.0 |

## Tests

```bash
pnpm --filter @sammati/react-native test
```

17 Vitest assertions cover the TS bridge contract — tenant id validation,
forwarding of every method to the native module, native-module-missing
diagnostics. Native side has its own suites:

- iOS: 30 XCTest assertions in [packages/sdk-ios/Tests/](../sdk-ios/Tests/)
- Android: 28 JUnit + Robolectric assertions in [packages/sdk-android/src/test/](../sdk-android/src/test/)

## License

Apache-2.0.
