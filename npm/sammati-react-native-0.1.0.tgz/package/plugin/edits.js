// Pure, testable string transforms for the Sammati Expo config plugin.
// No Expo imports here so they can be unit-tested without the Expo toolchain.

const SAMMATI_PODSPEC_URL =
  'https://raw.githubusercontent.com/sammatiind/sammati-sdks/main/cocoapods/Sammati.podspec';
const SAMMATI_MAVEN_URL =
  'https://raw.githubusercontent.com/sammatiind/sammati-sdks/main/maven';

// Inject `pod 'Sammati', :podspec => '<url>'` into the app target of a Podfile
// so CocoaPods can satisfy the RN bridge's transitive `s.dependency 'Sammati'`
// (a `:podspec =>` reference only resolves DIRECT pods, hence this injection).
// Idempotent; returns the input unchanged if Sammati is already present or no
// target block is found.
function addSammatiPod(podfile) {
  if (/pod\s+['"]Sammati['"]/.test(podfile)) return podfile;
  const target = podfile.match(/^([ \t]*)target\s+['"][^'"]+['"]\s+do.*$/m);
  if (!target) return podfile;
  const indent = target[1] + '  ';
  const line = `${indent}pod 'Sammati', :podspec => '${SAMMATI_PODSPEC_URL}'`;
  return podfile.replace(target[0], `${target[0]}\n${line}`);
}

// Add the Sammati Maven repo to the dependencyResolutionManagement repositories
// block of an Android settings.gradle[.kts] so `io.sammati:sdk-android` resolves
// (modern Expo/AGP sets RepositoriesMode.FAIL_ON_PROJECT_REPOS, so the repo MUST
// live in settings.gradle, not the module build.gradle). `kotlin` selects
// Kotlin-DSL vs Groovy syntax. Idempotent.
function addSammatiMaven(settings, kotlin) {
  if (settings.includes(SAMMATI_MAVEN_URL)) return settings;
  const re = /(dependencyResolutionManagement\s*\{[\s\S]*?repositories\s*\{)/;
  if (!re.test(settings)) return settings;
  const line = kotlin
    ? `\n        maven { url = uri("${SAMMATI_MAVEN_URL}") }`
    : `\n        maven { url '${SAMMATI_MAVEN_URL}' }`;
  return settings.replace(re, `$1${line}`);
}

module.exports = { addSammatiPod, addSammatiMaven, SAMMATI_PODSPEC_URL, SAMMATI_MAVEN_URL };
