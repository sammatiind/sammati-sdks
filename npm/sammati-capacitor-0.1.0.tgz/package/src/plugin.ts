// Plugin resolver. Production code path resolves the native plugin via
// Capacitor's `registerPlugin('Sammati', { web: () => new SammatiWeb() })`,
// which the host app's Capacitor runtime wires up at boot. Unit tests
// short-circuit that path via `setPluginForTesting()` so the suite runs
// in plain Node without a Capacitor runtime.
//
// We import `@capacitor/core` lazily and through a try/catch so the test
// surface (which sets a mock) can run on a machine where `@capacitor/core`
// is not installed (e.g. a CI worker that only checks out this package).

import type { SammatiPlugin } from './definitions.js';
import { SammatiWeb } from './web.js';

let testOverride: SammatiPlugin | null = null;
let registered: SammatiPlugin | null = null;

/**
 * Test-only injection point. Production code path lazily resolves via
 * Capacitor's `registerPlugin`; tests call this to swap in a mock that
 * records call arguments without booting a real Capacitor runtime.
 *
 * Call `setPluginForTesting(null)` in your test teardown to revert.
 */
export function setPluginForTesting(mock: SammatiPlugin | null): void {
  testOverride = mock;
}

interface CapacitorCoreModule {
  registerPlugin: <T>(
    name: string,
    impl: { web: () => T },
  ) => T;
}

export function resolvePlugin(): SammatiPlugin {
  if (testOverride) return testOverride;
  if (registered) return registered;

  let mod: CapacitorCoreModule | undefined;
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    mod = require('@capacitor/core') as CapacitorCoreModule;
  } catch {
    throw new Error(
      '@sammati/capacitor: @capacitor/core is not installed. ' +
        'This package only runs inside a Capacitor host app.',
    );
  }

  if (!mod || typeof mod.registerPlugin !== 'function') {
    throw new Error(
      '@sammati/capacitor: @capacitor/core does not expose registerPlugin. ' +
        'Upgrade to @capacitor/core >= 5.0.0.',
    );
  }

  registered = mod.registerPlugin<SammatiPlugin>('Sammati', {
    web: () => new SammatiWeb(),
  });
  return registered;
}
