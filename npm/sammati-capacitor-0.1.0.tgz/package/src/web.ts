// Capacitor requires every plugin to ship a web implementation as the
// fallback when the bundle runs in a non-native context (browser preview,
// Ionic dev server, etc.). Sammati's banner needs OS-trust surfaces
// (SFSafariViewController / Chrome Custom Tabs / native modal sheets)
// that the web shell can't provide — running a faux web banner would
// silently break DPDP §6 informed-consent. So the web layer throws on
// every method with a clear, actionable error.

import type {
  ConfigureOptions,
  GetChoicesResult,
  GetQueueDepthResult,
  OpenPreferenceCenterOptions,
  SammatiPlugin,
  SetLocaleOptions,
} from './definitions.js';

const WEB_NOT_SUPPORTED =
  '@sammati/capacitor: this SDK only runs on iOS or Android. ' +
  'Use @sammati/banner-sdk for browser environments.';

export class SammatiWeb implements SammatiPlugin {
  async configure(_options: ConfigureOptions): Promise<void> {
    throw new Error(WEB_NOT_SUPPORTED);
  }

  async showBannerIfNeeded(): Promise<void> {
    throw new Error(WEB_NOT_SUPPORTED);
  }

  async openPreferenceCenter(_options?: OpenPreferenceCenterOptions): Promise<void> {
    throw new Error(WEB_NOT_SUPPORTED);
  }

  async setLocale(_options: SetLocaleOptions): Promise<void> {
    throw new Error(WEB_NOT_SUPPORTED);
  }

  async getChoices(): Promise<GetChoicesResult> {
    throw new Error(WEB_NOT_SUPPORTED);
  }

  async withdraw(): Promise<void> {
    throw new Error(WEB_NOT_SUPPORTED);
  }

  async reset(): Promise<void> {
    throw new Error(WEB_NOT_SUPPORTED);
  }

  async flushOfflineQueue(): Promise<void> {
    throw new Error(WEB_NOT_SUPPORTED);
  }

  async getQueueDepth(): Promise<GetQueueDepthResult> {
    throw new Error(WEB_NOT_SUPPORTED);
  }
}
