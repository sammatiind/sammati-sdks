// Test surface for the Capacitor bridge.
//
// The point is NOT to re-test the iOS / Android SDKs — those have their
// own XCTest + Robolectric suites (MOB-01, MOB-02). The point is to
// assert the *bridge contract*:
//   - configure() validates the tenant id before bridging
//   - every public method forwards to the corresponding native method
//     with the right argument-object shape (Capacitor uses options
//     objects, not positional args — verifying we got the shape right
//     is the test that matters here)
//   - getChoices() / getQueueDepth() unwrap their result objects
//   - the web fallback throws a clear, actionable error
//   - native-module-not-linked / @capacitor/core-missing diagnostics
//     mention the package name
//
// We inject a mock plugin via setPluginForTesting() so the tests run in
// plain Node without a Capacitor runtime.

import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  Sammati,
  SammatiWeb,
  setPluginForTesting,
  type SammatiPlugin,
} from '../index.js';

function makeMockPlugin(): SammatiPlugin {
  return {
    configure: vi.fn().mockResolvedValue(undefined),
    showBannerIfNeeded: vi.fn().mockResolvedValue(undefined),
    openPreferenceCenter: vi.fn().mockResolvedValue(undefined),
    setLocale: vi.fn().mockResolvedValue(undefined),
    getChoices: vi.fn().mockResolvedValue({ choices: null }),
    withdraw: vi.fn().mockResolvedValue(undefined),
    reset: vi.fn().mockResolvedValue(undefined),
    flushOfflineQueue: vi.fn().mockResolvedValue(undefined),
    getQueueDepth: vi.fn().mockResolvedValue({ depth: 0 }),
  };
}

let pluginMock: SammatiPlugin;

beforeEach(() => {
  pluginMock = makeMockPlugin();
  setPluginForTesting(pluginMock);
});

afterEach(() => {
  setPluginForTesting(null);
});

describe('configure', () => {
  // ── Positive ────────────────────────────────────────────────────────────

  it('forwards tenant id with no baseURL key when baseURL omitted', async () => {
    await Sammati.configure({ tenantId: 'ten_abc123' });
    expect(pluginMock.configure).toHaveBeenCalledTimes(1);
    expect(pluginMock.configure).toHaveBeenCalledWith({ tenantId: 'ten_abc123' });
  });

  it('forwards explicit baseURL when provided', async () => {
    await Sammati.configure({
      tenantId: 'ten_abc123',
      baseURL: 'http://localhost:8000',
    });
    expect(pluginMock.configure).toHaveBeenCalledTimes(1);
    expect(pluginMock.configure).toHaveBeenCalledWith({
      tenantId: 'ten_abc123',
      baseURL: 'http://localhost:8000',
    });
  });

  // ── Negative / edge ─────────────────────────────────────────────────────

  it('throws synchronously on empty tenant id (does not call native)', async () => {
    await expect(Sammati.configure({ tenantId: '' })).rejects.toThrow(
      /non-empty string/,
    );
    expect(pluginMock.configure).not.toHaveBeenCalled();
  });

  it('throws synchronously on tenant id with disallowed characters', async () => {
    await expect(
      Sammati.configure({ tenantId: 'ten with spaces' }),
    ).rejects.toThrow(/\[a-zA-Z0-9_-\]\+/);
    expect(pluginMock.configure).not.toHaveBeenCalled();
  });

  it('throws synchronously on tenant id exceeding 64 chars', async () => {
    await expect(
      Sammati.configure({ tenantId: 'a'.repeat(65) }),
    ).rejects.toThrow(/longer than 64/);
    expect(pluginMock.configure).not.toHaveBeenCalled();
  });

  it('throws synchronously on tenant id with slash (path-traversal shape)', async () => {
    await expect(
      Sammati.configure({ tenantId: 'ten/admin' }),
    ).rejects.toThrow(/\[a-zA-Z0-9_-\]\+/);
    expect(pluginMock.configure).not.toHaveBeenCalled();
  });
});

describe('public method forwarding', () => {
  it('showBannerIfNeeded forwards to native', async () => {
    await Sammati.showBannerIfNeeded();
    expect(pluginMock.showBannerIfNeeded).toHaveBeenCalledOnce();
  });

  it('openPreferenceCenter forwards empty object when returnUrl omitted', async () => {
    await Sammati.openPreferenceCenter();
    expect(pluginMock.openPreferenceCenter).toHaveBeenCalledTimes(1);
    expect(pluginMock.openPreferenceCenter).toHaveBeenCalledWith({});
  });

  it('openPreferenceCenter forwards an explicit returnUrl', async () => {
    await Sammati.openPreferenceCenter({ returnUrl: 'myapp://prefs/done' });
    expect(pluginMock.openPreferenceCenter).toHaveBeenCalledTimes(1);
    expect(pluginMock.openPreferenceCenter).toHaveBeenCalledWith({
      returnUrl: 'myapp://prefs/done',
    });
  });

  it('setLocale wraps an explicit locale into the options object', async () => {
    await Sammati.setLocale('hi');
    expect(pluginMock.setLocale).toHaveBeenCalledTimes(1);
    expect(pluginMock.setLocale).toHaveBeenCalledWith({ locale: 'hi' });
  });

  it('setLocale wraps null into the options object', async () => {
    await Sammati.setLocale(null);
    expect(pluginMock.setLocale).toHaveBeenCalledTimes(1);
    expect(pluginMock.setLocale).toHaveBeenCalledWith({ locale: null });
  });

  it('getChoices unwraps the choices result', async () => {
    (pluginMock.getChoices as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      choices: { analytics: true, marketing: false },
    });
    const choices = await Sammati.getChoices();
    expect(choices).toEqual({ analytics: true, marketing: false });
  });

  it('getChoices returns null on a clean install (unwrapped)', async () => {
    const choices = await Sammati.getChoices();
    expect(choices).toBeNull();
  });

  it('withdraw forwards to native', async () => {
    await Sammati.withdraw();
    expect(pluginMock.withdraw).toHaveBeenCalledOnce();
  });

  it('reset forwards to native', async () => {
    await Sammati.reset();
    expect(pluginMock.reset).toHaveBeenCalledOnce();
  });

  it('flushOfflineQueue forwards to native', async () => {
    await Sammati.flushOfflineQueue();
    expect(pluginMock.flushOfflineQueue).toHaveBeenCalledOnce();
  });

  it('getQueueDepth unwraps the depth result', async () => {
    (pluginMock.getQueueDepth as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      depth: 3,
    });
    const depth = await Sammati.getQueueDepth();
    expect(depth).toBe(3);
  });
});

describe('web fallback', () => {
  it('throws a clear native-only error on every method', async () => {
    const web = new SammatiWeb();
    await expect(web.configure({ tenantId: 'x' })).rejects.toThrow(
      /only runs on iOS or Android/,
    );
    await expect(web.showBannerIfNeeded()).rejects.toThrow(
      /only runs on iOS or Android/,
    );
    await expect(web.openPreferenceCenter()).rejects.toThrow(
      /only runs on iOS or Android/,
    );
    await expect(web.setLocale({ locale: null })).rejects.toThrow(
      /only runs on iOS or Android/,
    );
    await expect(web.getChoices()).rejects.toThrow(
      /only runs on iOS or Android/,
    );
    await expect(web.withdraw()).rejects.toThrow(/only runs on iOS or Android/);
    await expect(web.reset()).rejects.toThrow(/only runs on iOS or Android/);
    await expect(web.flushOfflineQueue()).rejects.toThrow(
      /only runs on iOS or Android/,
    );
    await expect(web.getQueueDepth()).rejects.toThrow(
      /only runs on iOS or Android/,
    );
  });

  it('directs the user to @sammati/banner-sdk for browser use', async () => {
    const web = new SammatiWeb();
    await expect(web.showBannerIfNeeded()).rejects.toThrow(
      /@sammati\/banner-sdk/,
    );
  });
});

describe('plugin resolution', () => {
  it('throws a clear error when @capacitor/core is missing and no mock is set', async () => {
    setPluginForTesting(null);
    // In the Node test environment @capacitor/core is not installed
    // (this package is a peer dep, not a direct devDep at the workspace
    // level for this Node-only suite). The resolver should surface a
    // clear, actionable error that mentions the package name.
    await expect(Sammati.showBannerIfNeeded()).rejects.toThrow(
      /@sammati\/capacitor/,
    );
  });
});
