// MOB-08 — Capacitor plugin contract. Every method here forwards 1:1 to
// the iOS (MOB-01) and Android (MOB-02) native SDKs via the Capacitor
// plugin bridge. There is intentionally NO JS reimplementation of locale
// resolution, persistence, the offline queue, or the banner UI — the four
// host platforms (bare iOS, bare Android, RN, Capacitor) must behave
// identically on UX-compliance corner cases, which means one source of
// truth per behaviour and that source lives in the native SDK.
//
// All arguments cross the bridge as JSON, so every native-side method
// reads from a single `options` object (Capacitor convention) rather than
// positional args (RN convention). That asymmetry with @sammati/react-native
// is unavoidable — it's the Capacitor bridge calling convention.

export interface ConfigureOptions {
  /** Tenant id. Validated synchronously on the JS side before bridging. */
  tenantId: string;
  /** Optional override of the SDK production base URL. Local testing only. */
  baseURL?: string;
}

export interface OpenPreferenceCenterOptions {
  /** Deep-link the hosted preference centre redirects to on completion. */
  returnUrl?: string;
}

export interface SetLocaleOptions {
  /** ISO 639-1 locale code, or `null` to revert to the OS locale chain. */
  locale: string | null;
}

export interface GetChoicesResult {
  /**
   * Current choices envelope as a `{ purposeCode: granted }` map, or `null`
   * on a clean install / after `withdraw()`.
   */
  choices: Record<string, boolean> | null;
}

export interface GetQueueDepthResult {
  /** Number of unflushed offline writes. */
  depth: number;
}

/**
 * Capacitor plugin surface. Implementations live in
 *   - ios/Plugin/SammatiPlugin.swift (delegates to MOB-01)
 *   - android/src/main/java/io/sammati/sdk/capacitor/SammatiPlugin.kt
 *     (delegates to MOB-02)
 *   - src/web.ts (throws — Capacitor requires a web fallback; the SDK is
 *     native-only because DPDP-compliant consent capture needs OS-trust
 *     surfaces that the web shell can't provide)
 */
export interface SammatiPlugin {
  configure(options: ConfigureOptions): Promise<void>;
  showBannerIfNeeded(): Promise<void>;
  openPreferenceCenter(options?: OpenPreferenceCenterOptions): Promise<void>;
  setLocale(options: SetLocaleOptions): Promise<void>;
  getChoices(): Promise<GetChoicesResult>;
  withdraw(): Promise<void>;
  reset(): Promise<void>;
  flushOfflineQueue(): Promise<void>;
  getQueueDepth(): Promise<GetQueueDepthResult>;
}
