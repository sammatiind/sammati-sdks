// MOB-08 — Public TypeScript surface for the Capacitor adapter. Mirrors
// the iOS (`Sammati` Swift enum) and Android (`Sammati` Kotlin object)
// surfaces row-for-row, and matches the shape of @sammati/react-native so
// a customer team that ships on one bridge can pattern-match the other
// in minutes.
//
// Every method delegates to the native plugin via the Capacitor bridge.
// We validate the tenant id synchronously in JS so typos fail before a
// bridge round-trip; the native side validates again for the case where
// the JS surface is bypassed.

import { resolvePlugin } from './plugin.js';
import type { SammatiPlugin } from './definitions.js';

export type {
  ConfigureOptions,
  OpenPreferenceCenterOptions,
  SetLocaleOptions,
  GetChoicesResult,
  GetQueueDepthResult,
  SammatiPlugin,
} from './definitions.js';

export { SammatiWeb } from './web.js';
export { setPluginForTesting } from './plugin.js';

function assertTenantId(tenantId: unknown): asserts tenantId is string {
  if (typeof tenantId !== 'string' || tenantId.length === 0) {
    throw new Error('Sammati.configure: tenantId must be a non-empty string');
  }
  if (tenantId.length > 64) {
    throw new Error('Sammati.configure: tenantId is longer than 64 characters');
  }
  if (!/^[a-zA-Z0-9_-]+$/.test(tenantId)) {
    throw new Error(
      'Sammati.configure: tenantId must match [a-zA-Z0-9_-]+ ' +
        '(no spaces, no slashes, no special characters)',
    );
  }
}

export interface SammatiPublicApi {
  configure(options: { tenantId: string; baseURL?: string }): Promise<void>;
  showBannerIfNeeded(): Promise<void>;
  openPreferenceCenter(options?: { returnUrl?: string }): Promise<void>;
  setLocale(locale: string | null): Promise<void>;
  getChoices(): Promise<Record<string, boolean> | null>;
  withdraw(): Promise<void>;
  reset(): Promise<void>;
  flushOfflineQueue(): Promise<void>;
  getQueueDepth(): Promise<number>;
}

export const Sammati: SammatiPublicApi = {
  /**
   * Configure the SDK with the tenant id and (optionally) a custom backend
   * base URL. MUST be called once before any other method, typically in
   * the app's bootstrap (`main.ts` / `App.tsx`'s top-level `useEffect`).
   * Throws synchronously on a malformed tenant id.
   */
  async configure(options): Promise<void> {
    assertTenantId(options.tenantId);
    const plugin: SammatiPlugin = resolvePlugin();
    const out: { tenantId: string; baseURL?: string } = {
      tenantId: options.tenantId,
    };
    if (options.baseURL !== undefined) out.baseURL = options.baseURL;
    return plugin.configure(out);
  },

  /**
   * Show the native banner if no choices envelope exists for the current
   * notice version. Safe to call on every app launch / view mount.
   */
  async showBannerIfNeeded(): Promise<void> {
    return resolvePlugin().showBannerIfNeeded();
  },

  /**
   * Open the hosted preference centre via SFSafariViewController (iOS) or
   * Chrome Custom Tabs (Android). Never an embedded WebView — DPDP
   * disclosure must surface inside an OS-trust boundary.
   */
  async openPreferenceCenter(options = {}): Promise<void> {
    const out: OpenPreferenceCenterArg = {};
    if (options.returnUrl !== undefined) out.returnUrl = options.returnUrl;
    return resolvePlugin().openPreferenceCenter(out);
  },

  /**
   * Override the locale used by the banner. Pass `null` to revert to the
   * OS locale → server fallback chain.
   */
  async setLocale(locale): Promise<void> {
    return resolvePlugin().setLocale({ locale });
  },

  /** Read the current choices envelope. Returns null on a clean install. */
  async getChoices(): Promise<Record<string, boolean> | null> {
    const { choices } = await resolvePlugin().getChoices();
    return choices;
  },

  /**
   * Withdraw all current choices. Next `showBannerIfNeeded()` re-renders
   * the banner; the server-side withdrawal write goes through the offline
   * queue (so it survives a network drop).
   */
  async withdraw(): Promise<void> {
    return resolvePlugin().withdraw();
  },

  /**
   * Wipe ALL SDK state — choices, session id, offline queue. Intended for
   * QA / sign-out flows. Normal apps should never need this.
   */
  async reset(): Promise<void> {
    return resolvePlugin().reset();
  },

  /**
   * Drain queued consent writes. Idempotent; no-op when the queue is
   * empty. Call from Capacitor's `App` `appStateChange` listener when
   * `isActive=true`.
   */
  async flushOfflineQueue(): Promise<void> {
    return resolvePlugin().flushOfflineQueue();
  },

  /** Number of unflushed offline writes. Useful for QA UI badges. */
  async getQueueDepth(): Promise<number> {
    const { depth } = await resolvePlugin().getQueueDepth();
    return depth;
  },
};

type OpenPreferenceCenterArg = { returnUrl?: string };

export default Sammati;
