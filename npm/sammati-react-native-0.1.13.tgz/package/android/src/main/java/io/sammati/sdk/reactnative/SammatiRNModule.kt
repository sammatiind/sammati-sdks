package io.sammati.sdk.reactnative

import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.ReadableArray
import com.facebook.react.bridge.WritableNativeArray
import com.facebook.react.bridge.WritableNativeMap
import io.sammati.sdk.Sammati
import io.sammati.sdk.SammatiError
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * MOB-03 — React Native bridge for Android. Every method delegates to the
 * underlying `Sammati` object from packages/sdk-android. The bridge does
 * NOT re-implement locale resolution, persistence, or the offline queue;
 * doing so would let RN drift from bare Android on UX-compliance corner
 * cases.
 *
 * All methods are promise-based so the TS surface can `await` cleanly.
 */
class SammatiRNModule(private val reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun getName(): String = "SammatiRN"

    // ── configure ──────────────────────────────────────────────────────────

    @ReactMethod
    fun configure(tenantId: String, baseURL: String?, promise: Promise) {
        try {
            // Use the public default (RestClient is `internal` and unreachable
            // from this separate module). When baseURL is null/blank, omit it so
            // Sammati.configure applies its own default.
            val url = baseURL?.takeIf { it.isNotBlank() } ?: Sammati.DEFAULT_BASE_URL
            Sammati.configure(reactContext.applicationContext, tenantId = tenantId, baseUrl = url)
            promise.resolve(null)
        } catch (e: SammatiError.InvalidTenantId) {
            promise.reject("InvalidTenantId", "tenantId is malformed", e)
        } catch (e: Throwable) {
            promise.reject("ConfigureFailed", e.message, e)
        }
    }

    // ── showBannerIfNeeded ─────────────────────────────────────────────────

    @ReactMethod
    fun showBannerIfNeeded(promise: Promise) {
        val activity = reactContext.currentActivity
        if (activity == null) {
            promise.reject("NoActivity", "showBannerIfNeeded requires a foreground Activity")
            return
        }
        try {
            Sammati.showBannerIfNeeded(activity) {
                promise.resolve(null)
            }
        } catch (e: Throwable) {
            promise.reject("BannerFailed", e.message, e)
        }
    }

    // ── openPreferenceCenter ───────────────────────────────────────────────

    @ReactMethod
    fun openPreferenceCenter(returnUrl: String?, promise: Promise) {
        val activity = reactContext.currentActivity
        if (activity == null) {
            promise.reject("NoActivity", "openPreferenceCenter requires a foreground Activity")
            return
        }
        try {
            Sammati.openPreferenceCenter(activity, returnUrl = returnUrl)
            promise.resolve(null)
        } catch (e: Throwable) {
            promise.reject("PreferenceCenterFailed", e.message, e)
        }
    }

    // ── setLocale ──────────────────────────────────────────────────────────

    @ReactMethod
    fun setLocale(locale: String?, promise: Promise) {
        Sammati.setLocale(locale)
        promise.resolve(null)
    }

    // ── getChoices ─────────────────────────────────────────────────────────

    @ReactMethod
    fun getChoices(promise: Promise) {
        val choices = Sammati.getChoices()
        if (choices == null) {
            promise.resolve(null)
            return
        }
        val map = WritableNativeMap()
        for ((k, v) in choices) map.putBoolean(k, v)
        promise.resolve(map)
    }

    // ── withdraw / reset / flush ───────────────────────────────────────────

    @ReactMethod
    fun withdraw(promise: Promise) {
        try {
            Sammati.withdraw()
            promise.resolve(null)
        } catch (e: Throwable) {
            promise.reject("WithdrawFailed", e.message, e)
        }
    }

    @ReactMethod
    fun reset(promise: Promise) {
        try {
            Sammati.reset()
            promise.resolve(null)
        } catch (e: Throwable) {
            promise.reject("ResetFailed", e.message, e)
        }
    }

    @ReactMethod
    fun flushOfflineQueue(promise: Promise) {
        scope.launch {
            try {
                withContext(Dispatchers.IO) { Sammati.flushOfflineQueue() }
                promise.resolve(null)
            } catch (e: Throwable) {
                promise.reject("FlushFailed", e.message, e)
            }
        }
    }

    @ReactMethod
    fun getQueueDepth(promise: Promise) {
        promise.resolve(Sammati.queueDepth)
    }

    // ── Server-driven per-form consent ─────────────────────────────────────

    @ReactMethod
    fun getFormConsent(formKey: String, promise: Promise) {
        scope.launch {
            try {
                val spec = Sammati.getFormConsent(formKey)
                promise.resolve(spec?.let { specToMap(it) })
            } catch (e: Throwable) {
                promise.reject("GetFormConsentFailed", e.message, e)
            }
        }
    }

    @ReactMethod
    fun recordFormConsent(formKey: String, purposes: ReadableArray, principalId: String?, promise: Promise) {
        scope.launch {
            try {
                Sammati.recordFormConsent(formKey, purposes.toStringList(), principalId)
                promise.resolve(null)
            } catch (e: Throwable) {
                promise.reject("RecordFormConsentFailed", e.message, e)
            }
        }
    }

    @ReactMethod
    fun discoverForm(formKey: String, fields: ReadableArray, promise: Promise) {
        scope.launch {
            try {
                Sammati.discoverForm(formKey, fields.toStringList())
                promise.resolve(null)
            } catch (e: Throwable) {
                promise.reject("DiscoverFormFailed", e.message, e)
            }
        }
    }

    @ReactMethod
    fun formConsentState(formKey: String, principalId: String, promise: Promise) {
        scope.launch {
            try {
                val state = Sammati.formConsentState(formKey, principalId)
                val map = WritableNativeMap()
                map.putString("status", when (state.status) {
                    Sammati.FormConsentStatus.CONSENTED -> "consented"
                    Sammati.FormConsentStatus.NEEDS_CONSENT -> "needs_consent"
                    Sammati.FormConsentStatus.UNMAPPED -> "unmapped"
                })
                val v = state.noticeVersion
                if (v != null) map.putInt("noticeVersion", v) else map.putNull("noticeVersion")
                promise.resolve(map)
            } catch (e: Throwable) {
                promise.reject("FormConsentStateFailed", e.message, e)
            }
        }
    }

    private fun ReadableArray.toStringList(): List<String> {
        val out = ArrayList<String>(size())
        for (i in 0 until size()) getString(i)?.let { out.add(it) }
        return out
    }

    private fun specToMap(spec: Sammati.FormConsentSpec): WritableNativeMap {
        val map = WritableNativeMap()
        map.putString("formKey", spec.formKey)
        map.putString("uxMode", spec.uxMode)
        val purposes = WritableNativeArray()
        for (p in spec.purposes) {
            val pm = WritableNativeMap()
            pm.putString("code", p.code)
            pm.putString("basis", p.basis)
            pm.putBoolean("required", p.required)
            val labels = WritableNativeMap()
            for ((k, v) in p.labelI18n) labels.putString(k, v)
            pm.putMap("labelI18n", labels)
            purposes.pushMap(pm)
        }
        map.putArray("purposes", purposes)
        val notice = spec.notice
        if (notice == null) {
            map.putNull("notice")
        } else {
            val nm = WritableNativeMap()
            nm.putString("id", notice.id)
            nm.putInt("version", notice.version)
            nm.putString("defaultLanguage", notice.defaultLanguage)
            val contents = WritableNativeArray()
            for (c in notice.contents) {
                val cm = WritableNativeMap()
                cm.putString("language", c.language)
                cm.putString("title", c.title)
                cm.putString("body", c.body)
                cm.putString("shortDescription", c.shortDescription)
                contents.pushMap(cm)
            }
            nm.putArray("contents", contents)
            map.putMap("notice", nm)
        }
        return map
    }
}
