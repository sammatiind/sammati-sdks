// MOB-03 — React Native bridge for iOS. Every method delegates to the
// underlying `Sammati` SDK from packages/sdk-ios. There is intentionally
// NO logic here beyond:
//   1. Arg unwrapping (NSString → String, NSNull → nil).
//   2. Resolving the top view controller for present-from operations.
//   3. Promise resolve/reject plumbing.
//
// Re-implementing locale resolution, persistence, or the offline queue
// in JS would let the four host platforms (bare iOS, bare Android, RN,
// Capacitor) drift on UX-compliance corner cases. We refuse to do that.

import Foundation
import UIKit
import Sammati

@objc(SammatiRN)
final class SammatiRNModule: NSObject {

  @objc static func requiresMainQueueSetup() -> Bool { true }

  // ── configure ──────────────────────────────────────────────────────────

  @objc(configure:baseURL:resolver:rejecter:)
  func configure(
    _ tenantId: String,
    baseURL: NSString?,
    resolver resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    let urlOrDefault: URL
    if let raw = baseURL as String?, let parsed = URL(string: raw) {
      urlOrDefault = parsed
    } else {
      urlOrDefault = RestClient.defaultBaseURL
    }
    Sammati.configure(tenantId: tenantId, baseURL: urlOrDefault)
    resolve(nil)
  }

  // ── showBannerIfNeeded ─────────────────────────────────────────────────

  @objc(showBannerIfNeeded:rejecter:)
  func showBannerIfNeeded(
    _ resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    DispatchQueue.main.async {
      guard let presenter = self.topViewController() else {
        reject("NoPresenter", "Could not resolve a top view controller to present from", nil)
        return
      }
      Sammati.showBannerIfNeeded(from: presenter) {
        resolve(nil)
      }
    }
  }

  // ── openPreferenceCenter ───────────────────────────────────────────────

  @objc(openPreferenceCenter:resolver:rejecter:)
  func openPreferenceCenter(
    _ returnUrl: NSString?,
    resolver resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    DispatchQueue.main.async {
      guard let presenter = self.topViewController() else {
        reject("NoPresenter", "Could not resolve a top view controller to present from", nil)
        return
      }
      let url: URL? = (returnUrl as String?).flatMap { URL(string: $0) }
      Sammati.openPreferenceCenter(from: presenter, returnUrl: url)
      resolve(nil)
    }
  }

  // ── setLocale ──────────────────────────────────────────────────────────

  @objc(setLocale:resolver:rejecter:)
  func setLocale(
    _ locale: NSString?,
    resolver resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    Sammati.setLocale(locale as String?)
    resolve(nil)
  }

  // ── getChoices ─────────────────────────────────────────────────────────

  @objc(getChoices:rejecter:)
  func getChoices(
    _ resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    let choices = Sammati.getChoices()
    resolve(choices) // NSNull bridges to JS null when nil
  }

  // ── withdraw / reset / flush ───────────────────────────────────────────

  @objc(withdraw:rejecter:)
  func withdraw(
    _ resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    Sammati.withdraw()
    resolve(nil)
  }

  @objc(reset:rejecter:)
  func reset(
    _ resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    Sammati.reset()
    resolve(nil)
  }

  @objc(flushOfflineQueue:rejecter:)
  func flushOfflineQueue(
    _ resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    Task {
      await Sammati.flushOfflineQueue()
      resolve(nil)
    }
  }

  @objc(getQueueDepth:rejecter:)
  func getQueueDepth(
    _ resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    resolve(Sammati.queueDepth)
  }

  // ── Server-driven per-form consent ─────────────────────────────────────

  @objc(getFormConsent:resolver:rejecter:)
  func getFormConsent(
    _ formKey: String,
    resolver resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    Task {
      do {
        let spec = try await Sammati.getFormConsent(formKey: formKey)
        resolve(spec.map { Self.specToDict($0) } ?? NSNull())
      } catch {
        reject("GetFormConsentFailed", (error as? SammatiError)?.code ?? "\(error)", error)
      }
    }
  }

  @objc(recordFormConsent:purposes:principalId:resolver:rejecter:)
  func recordFormConsent(
    _ formKey: String,
    purposes: NSArray,
    principalId: NSString?,
    resolver resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    let codes = purposes.compactMap { $0 as? String }
    Task {
      do {
        try await Sammati.recordFormConsent(formKey: formKey, consentedPurposes: codes, principalId: principalId as String?)
        resolve(nil)
      } catch {
        reject("RecordFormConsentFailed", (error as? SammatiError)?.code ?? "\(error)", error)
      }
    }
  }

  @objc(discoverForm:fields:resolver:rejecter:)
  func discoverForm(
    _ formKey: String,
    fields: NSArray,
    resolver resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    let names = fields.compactMap { $0 as? String }
    Task {
      do {
        try await Sammati.discoverForm(formKey: formKey, fields: names)
        resolve(nil)
      } catch {
        reject("DiscoverFormFailed", (error as? SammatiError)?.code ?? "\(error)", error)
      }
    }
  }

  @objc(formConsentState:principalId:resolver:rejecter:)
  func formConsentState(
    _ formKey: String,
    principalId: String,
    resolver resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    Task {
      do {
        let state = try await Sammati.formConsentState(formKey: formKey, principalId: principalId)
        let status: String
        switch state.status {
        case .consented:    status = "consented"
        case .needsConsent: status = "needs_consent"
        case .unmapped:     status = "unmapped"
        }
        resolve(["status": status, "noticeVersion": state.noticeVersion as Any])
      } catch {
        reject("FormConsentStateFailed", (error as? SammatiError)?.code ?? "\(error)", error)
      }
    }
  }

  private static func specToDict(_ spec: Sammati.FormConsentSpec) -> [String: Any] {
    var dict: [String: Any] = [
      "formKey": spec.formKey,
      "uxMode": spec.uxMode,
      "purposes": spec.purposes.map { p -> [String: Any] in
        ["code": p.code, "basis": p.basis, "required": p.required, "labelI18n": p.labelI18n]
      },
    ]
    if let n = spec.notice {
      dict["notice"] = [
        "id": n.id,
        "version": n.version,
        "defaultLanguage": n.defaultLanguage,
        "contents": n.contents.map { c -> [String: Any] in
          ["language": c.language, "title": c.title, "body": c.body, "shortDescription": c.shortDescription]
        },
      ] as [String: Any]
    } else {
      dict["notice"] = NSNull()
    }
    return dict
  }

  // ── Helpers ────────────────────────────────────────────────────────────

  /// Walks the active scene's window hierarchy to find the topmost
  /// presented view controller. We avoid `keyWindow` (deprecated since
  /// iOS 13) and prefer the scene-based path.
  private func topViewController() -> UIViewController? {
    let scenes = UIApplication.shared.connectedScenes
      .compactMap { $0 as? UIWindowScene }
      .filter { $0.activationState == .foregroundActive }
    let window = scenes.flatMap { $0.windows }.first(where: { $0.isKeyWindow })
      ?? scenes.flatMap { $0.windows }.first
    var top = window?.rootViewController
    while let presented = top?.presentedViewController {
      top = presented
    }
    return top
  }
}
