# @sammati/sdk-node

Official Node.js SDK for the [Sammati](https://sammati.in) Consent API — DPDP-native consent and privacy platform.

## Install

```bash
pnpm add @sammati/sdk-node
# or: npm i @sammati/sdk-node
```

Requires Node ≥ 18 (uses the built-in `fetch`).

## Quickstart

```ts
import { Sammati } from '@sammati/sdk-node';

const sammati = new Sammati({
  apiKey: process.env.SAMMATI_API_KEY!,        // sm_live_... or sm_test_...
  // apiBase: 'https://api.sammati.in',         // override for self-hosted/BYOC
});

// 1. List published purposes for the tenant
const { data: purposes } = await sammati.purposes.list({ status: 'published' });

// 2. Record a server-side consent (idempotency-key auto-generated)
const artifact = await sammati.consents.give({
  principal_id: 'usr_42',
  notice_id: 'not_xyz',
  notice_version: 3,
  collection_method: 'server_api',
  purposes: purposes.map((p) => ({ purpose_id: p.id, decision: 'accepted' })),
});

console.log(artifact.id, artifact.signed_at);
```

## What's in the box

| Resource          | Endpoints                                                                |
| ----------------- | ------------------------------------------------------------------------ |
| `tenants`         | `current`, `get`, `update`, `switchEnvironment`                          |
| `purposes`        | `list`, `get`, `create`, `update`, `publish`, `deprecate`                |
| `notices`         | `list`, `get`, `create`, `publish`, `archive`, `deleteDraft`, `putTranslation` |
| `consents`        | `list`, `get`, `give`, `withdraw`, `bulk`, `verify`                      |
| `rights`          | `list`, `get`, `create`, `transition`, `downloadPackage`                 |
| `parental`        | `list`, `get`, `create`, `sendOtp`, `verifyOtp`, `decide`                |
| `prefs`           | `requestToken`, `sendOtp`, `verifyOtp`, `withToken().{status,update,withdrawAll}` |
| `reports`         | `consentActivity`, `ledger`, `ledgerIntegrity`                           |

## Configuration

```ts
new Sammati({
  apiKey: 'sm_live_...',     // required
  apiBase: 'https://api.sammati.in',
  timeoutMs: 30_000,
  maxRetries: 3,             // retries on 5xx, 429, network errors
  userAgent: 'my-app/1.0',
  onRequest: (info) => log(info), // observability hook
});
```

## Error handling

Every API failure throws a typed subclass of `SammatiError`. Switch on the class — never on the message string.

```ts
import {
  SammatiAuthError,
  SammatiRateLimitError,
  SammatiQuotaError,
  SammatiValidationError,
  SammatiNotFoundError,
  SammatiEntitlementError,
  SammatiConnectionError,
} from '@sammati/sdk-node';

try {
  await sammati.consents.give(input);
} catch (err) {
  if (err instanceof SammatiQuotaError) {
    // err.quotaKey, err.limit, err.currentUsage are typed
  } else if (err instanceof SammatiRateLimitError) {
    await sleep((err.retryAfter ?? 1) * 1000);
  } else if (err instanceof SammatiAuthError) {
    // re-mint API key / re-auth
  } else if (err instanceof SammatiConnectionError) {
    // network exhaustion after retries
  } else {
    throw err;
  }
}
```

## Idempotency

Every write call (POST/PATCH/PUT/DELETE) gets an auto-generated [ULID](https://github.com/ulid/spec) `Idempotency-Key`. To override or suppress:

```ts
await sammati.consents.give(payload, { idempotencyKey: 'order-7421-consent' });
```

Retries on 5xx/429 reuse the same key, so the API will dedupe on the server side.

## Preference center (end-user flows)

```ts
// Server-side: mint a short-lived token for the principal
const { prefs_token } = await sammati.prefs.requestToken({
  principal_id: 'usr_42',
  contact: 'user@example.com',
  contact_kind: 'email',
});

// Client-side or downstream: scoped to the principal, no API key needed
const status = await sammati.prefs.withToken(prefs_token).status();
await sammati.prefs.withToken(prefs_token).update({
  decisions: [{ purpose_id: 'pur_marketing', decision: 'rejected' }],
});
```

## Bulk ingestion

```ts
const result = await sammati.consents.bulk(items); // up to 1000 per call
console.log(`${result.succeeded}/${result.total} ingested`);
for (const item of result.items.filter((i) => i.status === 'error')) {
  console.error('row', item.index, item.error);
}
```

## Reports & ledger

```ts
// CSV / PDF return raw bytes
const csv = await sammati.reports.consentActivity({
  from: '2026-01-01',
  to: '2026-01-31',
  format: 'csv',
});
fs.writeFileSync('report.csv', csv);

// Verify hash-chain integrity for compliance audits
const integrity = await sammati.reports.ledgerIntegrity();
if (!integrity.ok) throw new Error(`Ledger broken at ${integrity.broken_at}`);
```

## License

Apache-2.0
