// React Native autolinking config (RN ≥ 0.60). Tells the host app's
// native build to pick up our iOS pod + Android Gradle module without
// the customer having to edit Podfile / settings.gradle by hand.
module.exports = {
  dependency: {
    platforms: {
      ios: {
        // Filename MUST match the pod name (`SammatiRN`) — RN 0.71+/Expo
        // autolinking locates the podspec by pod name, not this path.
        podspecPath: __dirname + '/SammatiRN.podspec',
      },
      android: {
        sourceDir: __dirname + '/android',
        packageImportPath: 'import io.sammati.sdk.reactnative.SammatiRNPackage;',
        packageInstance: 'new SammatiRNPackage()',
      },
    },
  },
};
