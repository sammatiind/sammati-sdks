// Native-module spec — the raw bridge surface that the host app's
// React Native runtime resolves via NativeModules. We import this through
// a thin getter (`getNativeModule()`) so the TypeScript surface in
// index.ts can be unit-tested without a running RN runtime — tests
// inject a mock module via setNativeModule().
//
// We deliberately use the legacy bridge (NativeModules + @ReactMethod)
// rather than TurboModules to keep the consumer-side install story to
// just `npm install + autolink` — TurboModules require codegen on every
// host app's build pipeline. The native methods are all promise-based
// (resolve/reject) on both platforms; getter properties (queueDepth)
// are exposed as `getQueueDepth(): Promise<number>` to keep the shape
// uniform across the JSI boundary.

/** Published consent mapping for a single app form (from getFormConsent). */
export interface FormConsentSpec {
  formKey: string;
  uxMode: string;
  purposes: Array<{ code: string; basis: string; required: boolean; labelI18n: Record<string, string> }>;
  notice: {
    id: string;
    version: number;
    defaultLanguage: string;
    contents: Array<{ language: string; title: string; body: string; shortDescription: string }>;
  } | null;
}

export interface NativeSammatiModule {
  /**
   * configure(tenantId, baseURL | null) — MUST be called once before any
   * other native call. Rejects with `InvalidTenantId` on a malformed id.
   */
  configure(tenantId: string, baseURL: string | null): Promise<void>;

  /** showBannerIfNeeded() — renders the native modal sheet if no choices
   *  envelope exists for the current notice version. No-op otherwise. */
  showBannerIfNeeded(): Promise<void>;

  /** openPreferenceCenter(returnUrl | null) — opens SFSafariViewController
   *  (iOS) / Chrome Custom Tab (Android). No WebView. */
  openPreferenceCenter(returnUrl: string | null): Promise<void>;

  /** setLocale(locale | null) — explicit override. Pass null to revert. */
  setLocale(locale: string | null): Promise<void>;

  /** getChoices() → current choices envelope, or null on a clean install. */
  getChoices(): Promise<Record<string, boolean> | null>;

  /** withdraw() — clears choices envelope; next showBannerIfNeeded()
   *  re-renders. Server-side withdrawal is posted via the offline queue. */
  withdraw(): Promise<void>;

  /** reset() — wipes ALL SDK state (choices + session id + queue).
   *  Intended for QA / sign-out flows, not normal app usage. */
  reset(): Promise<void>;

  /** flushOfflineQueue() — drains queued consent writes. Safe to call
   *  on every foreground; no-op if the queue is empty. */
  flushOfflineQueue(): Promise<void>;

  /** getQueueDepth() → number of unflushed queued writes. */
  getQueueDepth(): Promise<number>;

  /** getFormConsent(formKey) → the published mapping for an app form, or null
   *  if the admin hasn't mapped it. The app renders its own consent UI. */
  getFormConsent(formKey: string): Promise<FormConsentSpec | null>;

  /** recordFormConsent(formKey, purposes, principalId | null) — records the
   *  user's consent on a form submit. `purposes` is the subset consented to. */
  recordFormConsent(formKey: string, purposes: string[], principalId: string | null): Promise<void>;

  /** discoverForm(formKey, fields) — registers an app form (by its field
   *  names) so it appears in the /pii-forms App tab for an admin to map. */
  discoverForm(formKey: string, fields: string[]): Promise<void>;
}

let nativeOverride: NativeSammatiModule | null = null;

/**
 * Test-only injection point. Production code path resolves the native
 * module via NativeModules.SammatiRN; unit tests call this to swap in a
 * mock that records call arguments without booting a real RN runtime.
 */
export function setNativeModule(mock: NativeSammatiModule | null): void {
  nativeOverride = mock;
}

/**
 * Resolve the native module. We import react-native lazily and through a
 * try/catch so the unit-test surface (which sets a mock) can run in plain
 * Node where `react-native` is not installed.
 */
export function getNativeModule(): NativeSammatiModule {
  if (nativeOverride) return nativeOverride;

  let NativeModules: Record<string, NativeSammatiModule | undefined> | undefined;
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    NativeModules = require('react-native').NativeModules;
  } catch {
    throw new Error(
      '@sammati/react-native: react-native is not installed. ' +
        'This package only runs inside a React Native app.',
    );
  }

  const mod = NativeModules?.['SammatiRN'];
  if (!mod) {
    throw new Error(
      '@sammati/react-native: native module `SammatiRN` is not linked. ' +
        'Run `pod install` (iOS) and rebuild the Android app. RN ≥ 0.60 ' +
        'should autolink — if you are on an older version, link manually.',
    );
  }
  return mod;
}
