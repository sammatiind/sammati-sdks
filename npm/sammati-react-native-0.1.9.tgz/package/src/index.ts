// Public TypeScript surface — mirrors the iOS (`Sammati` Swift enum) and
// Android (`Sammati` Kotlin object) APIs row-for-row, so a customer team
// that has shipped on one platform can pattern-match the others in
// minutes. Every method delegates to the native bridge — there is NO
// JavaScript re-implementation of locale resolution, persistence, or the
// offline queue. That protects the UX-compliance invariant: the SDK
// behaves identically whether the host app is bare native, RN, Capacitor,
// or (eventually) Flutter.

import { getNativeModule, type FormConsentSpec } from './NativeSammati';

export { setNativeModule } from './NativeSammati';
export type { NativeSammatiModule, FormConsentSpec } from './NativeSammati';

/** Argument to configure(). baseURL defaults to the SDK's production
 *  default; override for local testing against a self-hosted core-api. */
export interface ConfigureOptions {
  tenantId: string;
  baseURL?: string;
}

/** Argument to openPreferenceCenter(). returnUrl, if provided, is the
 *  deep-link the hosted preference centre redirects to on completion. */
export interface OpenPreferenceCenterOptions {
  returnUrl?: string;
}

function assertTenantId(tenantId: unknown): asserts tenantId is string {
  if (typeof tenantId !== 'string' || tenantId.length === 0) {
    throw new Error('Sammati.configure: tenantId must be a non-empty string');
  }
  if (tenantId.length > 64) {
    throw new Error('Sammati.configure: tenantId is longer than 64 characters');
  }
  if (!/^[a-zA-Z0-9_-]+$/.test(tenantId)) {
    throw new Error(
      'Sammati.configure: tenantId must match [a-zA-Z0-9_-]+ ' +
        '(no spaces, no slashes, no special characters)',
    );
  }
}

export const Sammati = {
  /**
   * Configure the SDK with the tenant id and (optionally) a custom backend
   * base URL. MUST be called once before any other method. Throws
   * synchronously on a malformed tenant id — the same validation runs
   * again on the native side, but failing early in JS lets developers
   * catch typos without a round-trip.
   */
  async configure(options: ConfigureOptions): Promise<void> {
    assertTenantId(options.tenantId);
    return getNativeModule().configure(options.tenantId, options.baseURL ?? null);
  },

  /**
   * Show the native banner if no choices envelope exists for the current
   * notice version. Safe to call on every app launch / screen mount.
   */
  async showBannerIfNeeded(): Promise<void> {
    return getNativeModule().showBannerIfNeeded();
  },

  /**
   * Open the hosted preference centre. Uses SFSafariViewController on iOS
   * and Chrome Custom Tabs on Android — never an embedded WebView (DPDP
   * disclosure must be in an OS-trust-boundary surface, not a custom-skin
   * view a malicious app could spoof).
   */
  async openPreferenceCenter(options: OpenPreferenceCenterOptions = {}): Promise<void> {
    return getNativeModule().openPreferenceCenter(options.returnUrl ?? null);
  },

  /**
   * Override the locale used by the banner. Pass `null` to revert to the
   * OS locale → server fallback chain.
   */
  async setLocale(locale: string | null): Promise<void> {
    return getNativeModule().setLocale(locale);
  },

  /** Read the current choices envelope. Returns null on a clean install. */
  async getChoices(): Promise<Record<string, boolean> | null> {
    return getNativeModule().getChoices();
  },

  /**
   * Withdraw all current choices. Next `showBannerIfNeeded()` re-renders
   * the banner; the server-side withdrawal write goes through the offline
   * queue (so it survives a network drop).
   */
  async withdraw(): Promise<void> {
    return getNativeModule().withdraw();
  },

  /**
   * Wipe ALL SDK state — choices, session id, offline queue. Intended for
   * QA / sign-out flows. Normal apps should never need this.
   */
  async reset(): Promise<void> {
    return getNativeModule().reset();
  },

  /**
   * Drain queued consent writes. Idempotent; no-op when the queue is
   * empty. Call from your app's foreground hook (AppState 'active').
   */
  async flushOfflineQueue(): Promise<void> {
    return getNativeModule().flushOfflineQueue();
  },

  /** Number of unflushed offline writes. Useful for QA UI badges. */
  async getQueueDepth(): Promise<number> {
    return getNativeModule().getQueueDepth();
  },

  /**
   * Server-driven per-form consent. Mobile apps have no DOM to auto-scan, so
   * each PII form (signup, checkout, …) is instrumented under a stable
   * `formKey`; the org maps a notice + purposes to it in the /pii-forms portal
   * (no app rebuild). See the SDK README for the formKey convention.
   */

  /** Fetch the published mapping for a form, or null if unmapped. Render your
   *  own native consent UI (toggles per purpose) from the result. */
  async getFormConsent(formKey: string): Promise<FormConsentSpec | null> {
    return getNativeModule().getFormConsent(formKey);
  },

  /** Record the user's consent on form submit. `consentedPurposes` is the
   *  subset of the mapping's purposes they agreed to; `principalId` is the
   *  identifier (email/phone) to link the artifact, or null for anonymous. */
  async recordFormConsent(
    formKey: string,
    consentedPurposes: string[],
    principalId: string | null = null,
  ): Promise<void> {
    return getNativeModule().recordFormConsent(formKey, consentedPurposes, principalId);
  },

  /** Register an app form by its field names so it appears in the portal's
   *  App tab for an admin to map. Best-effort; safe to call on form view. */
  async discoverForm(formKey: string, fields: string[]): Promise<void> {
    return getNativeModule().discoverForm(formKey, fields);
  },
} as const;

export default Sammati;
