// Test surface for the React Native bridge.
//
// The point is NOT to re-test the iOS / Android SDKs — those have their
// own XCTest + Robolectric suites (MOB-01, MOB-02). The point is to
// assert the *bridge contract*:
//   - configure() validates the tenant id before calling native
//   - every public method forwards to the corresponding native method
//     with the right argument shape
//   - the native-module-not-linked error is clear and actionable
//
// We inject a mock native module via setNativeModule() so the tests run
// in plain Node without a React Native runtime.

import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  Sammati,
  setNativeModule,
  type NativeSammatiModule,
} from '../index.js';

function makeMockModule(): NativeSammatiModule {
  return {
    configure: vi.fn().mockResolvedValue(undefined),
    showBannerIfNeeded: vi.fn().mockResolvedValue(undefined),
    openPreferenceCenter: vi.fn().mockResolvedValue(undefined),
    setLocale: vi.fn().mockResolvedValue(undefined),
    getChoices: vi.fn().mockResolvedValue(null),
    withdraw: vi.fn().mockResolvedValue(undefined),
    reset: vi.fn().mockResolvedValue(undefined),
    flushOfflineQueue: vi.fn().mockResolvedValue(undefined),
    getQueueDepth: vi.fn().mockResolvedValue(0),
    getFormConsent: vi.fn().mockResolvedValue(null),
    recordFormConsent: vi.fn().mockResolvedValue(undefined),
    discoverForm: vi.fn().mockResolvedValue(undefined),
  };
}

let nativeMock: NativeSammatiModule;

beforeEach(() => {
  nativeMock = makeMockModule();
  setNativeModule(nativeMock);
});

afterEach(() => {
  setNativeModule(null);
});

describe('configure', () => {
  // ── Positive ────────────────────────────────────────────────────────────

  it('forwards tenant id + default null baseURL to native', async () => {
    await Sammati.configure({ tenantId: 'ten_abc123' });
    expect(nativeMock.configure).toHaveBeenCalledTimes(1);
    expect(nativeMock.configure).toHaveBeenCalledWith('ten_abc123', null);
  });

  it('forwards explicit baseURL when provided', async () => {
    await Sammati.configure({
      tenantId: 'ten_abc123',
      baseURL: 'http://localhost:8000',
    });
    expect(nativeMock.configure).toHaveBeenCalledTimes(1);
    expect(nativeMock.configure).toHaveBeenCalledWith(
      'ten_abc123',
      'http://localhost:8000',
    );
  });

  // ── Negative / edge ─────────────────────────────────────────────────────

  it('throws synchronously on empty tenant id (does not call native)', async () => {
    await expect(Sammati.configure({ tenantId: '' })).rejects.toThrow(
      /non-empty string/,
    );
    expect(nativeMock.configure).not.toHaveBeenCalled();
  });

  it('throws synchronously on tenant id with disallowed characters', async () => {
    await expect(
      Sammati.configure({ tenantId: 'ten with spaces' }),
    ).rejects.toThrow(/\[a-zA-Z0-9_-\]\+/);
    expect(nativeMock.configure).not.toHaveBeenCalled();
  });

  it('throws synchronously on tenant id exceeding 64 chars', async () => {
    await expect(
      Sammati.configure({ tenantId: 'a'.repeat(65) }),
    ).rejects.toThrow(/longer than 64/);
    expect(nativeMock.configure).not.toHaveBeenCalled();
  });
});

describe('public method forwarding', () => {
  it('showBannerIfNeeded forwards to native', async () => {
    await Sammati.showBannerIfNeeded();
    expect(nativeMock.showBannerIfNeeded).toHaveBeenCalledOnce();
  });

  it('openPreferenceCenter forwards null returnUrl by default', async () => {
    await Sammati.openPreferenceCenter();
    expect(nativeMock.openPreferenceCenter).toHaveBeenCalledTimes(1);
    expect(nativeMock.openPreferenceCenter).toHaveBeenCalledWith(null);
  });

  it('openPreferenceCenter forwards an explicit returnUrl', async () => {
    await Sammati.openPreferenceCenter({ returnUrl: 'myapp://prefs/done' });
    expect(nativeMock.openPreferenceCenter).toHaveBeenCalledTimes(1);
    expect(nativeMock.openPreferenceCenter).toHaveBeenCalledWith(
      'myapp://prefs/done',
    );
  });

  it('setLocale forwards an explicit locale string', async () => {
    await Sammati.setLocale('hi');
    expect(nativeMock.setLocale).toHaveBeenCalledTimes(1);
    expect(nativeMock.setLocale).toHaveBeenCalledWith('hi');
  });

  it('setLocale forwards null to revert to OS locale', async () => {
    await Sammati.setLocale(null);
    expect(nativeMock.setLocale).toHaveBeenCalledTimes(1);
    expect(nativeMock.setLocale).toHaveBeenCalledWith(null);
  });

  it('getChoices forwards the native result verbatim', async () => {
    (nativeMock.getChoices as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      analytics: true,
      marketing: false,
    });
    const choices = await Sammati.getChoices();
    expect(choices).toEqual({ analytics: true, marketing: false });
  });

  it('getChoices returns null on a clean install', async () => {
    const choices = await Sammati.getChoices();
    expect(choices).toBeNull();
  });

  it('withdraw forwards to native', async () => {
    await Sammati.withdraw();
    expect(nativeMock.withdraw).toHaveBeenCalledOnce();
  });

  it('reset forwards to native', async () => {
    await Sammati.reset();
    expect(nativeMock.reset).toHaveBeenCalledOnce();
  });

  it('flushOfflineQueue forwards to native', async () => {
    await Sammati.flushOfflineQueue();
    expect(nativeMock.flushOfflineQueue).toHaveBeenCalledOnce();
  });

  it('getQueueDepth forwards the native result', async () => {
    (nativeMock.getQueueDepth as ReturnType<typeof vi.fn>).mockResolvedValueOnce(
      3,
    );
    const depth = await Sammati.getQueueDepth();
    expect(depth).toBe(3);
  });
});

describe('server-driven form consent', () => {
  it('getFormConsent forwards the formKey and returns the native spec verbatim', async () => {
    const spec = {
      formKey: 'mobile:com.tantupratha.app:signup',
      uxMode: 'inline_overlay',
      purposes: [{ code: 'marketing', basis: 'consent', required: false, labelI18n: { en: 'Marketing' } }],
      notice: { id: 'n1', version: 2, defaultLanguage: 'en', contents: [] },
    };
    (nativeMock.getFormConsent as ReturnType<typeof vi.fn>).mockResolvedValueOnce(spec);
    const out = await Sammati.getFormConsent('mobile:com.tantupratha.app:signup');
    expect(nativeMock.getFormConsent).toHaveBeenCalledWith('mobile:com.tantupratha.app:signup');
    expect(out).toEqual(spec);
  });

  it('getFormConsent returns null for an unmapped form', async () => {
    const out = await Sammati.getFormConsent('mobile:com.tantupratha.app:unknown');
    expect(out).toBeNull();
  });

  it('recordFormConsent forwards formKey, purposes and an explicit principalId', async () => {
    await Sammati.recordFormConsent('mobile:app:signup', ['marketing'], 'user@example.com');
    expect(nativeMock.recordFormConsent).toHaveBeenCalledWith('mobile:app:signup', ['marketing'], 'user@example.com');
  });

  it('recordFormConsent defaults principalId to null when omitted', async () => {
    await Sammati.recordFormConsent('mobile:app:signup', ['marketing']);
    expect(nativeMock.recordFormConsent).toHaveBeenCalledWith('mobile:app:signup', ['marketing'], null);
  });

  it('discoverForm forwards the formKey and field names', async () => {
    await Sammati.discoverForm('mobile:app:signup', ['email', 'name']);
    expect(nativeMock.discoverForm).toHaveBeenCalledWith('mobile:app:signup', ['email', 'name']);
  });
});

describe('native-module resolution', () => {
  it('throws a clear error when no native module is linked and no mock is set', async () => {
    setNativeModule(null);
    // We can't easily make `require('react-native')` fail or succeed
    // deterministically from inside the test, so we assert the error
    // mentions both the package name and a remediation hint — covers
    // both branches (RN not installed, OR native module not linked).
    await expect(Sammati.showBannerIfNeeded()).rejects.toThrow(
      /@sammati\/react-native/,
    );
  });
});
