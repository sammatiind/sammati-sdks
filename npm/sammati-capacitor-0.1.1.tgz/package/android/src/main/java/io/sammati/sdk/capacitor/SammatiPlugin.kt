// MOB-08 — Capacitor plugin for Android. Every method delegates to the
// underlying `Sammati` SDK from packages/sdk-android. There is intentionally
// NO logic here beyond:
//   1. Reading typed args off the PluginCall.
//   2. Reaching the host activity for present-from operations.
//   3. PluginCall resolve/reject plumbing.
//
// We refuse to re-implement locale resolution, persistence, or the offline
// queue in JS — those behaviours must be identical across the four host
// platforms (bare iOS, bare Android, RN, Capacitor) and only the native
// SDK is the source of truth.

package io.sammati.sdk.capacitor

import androidx.appcompat.app.AppCompatActivity
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import io.sammati.sdk.Sammati
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@CapacitorPlugin(name = "Sammati")
class SammatiPlugin : Plugin() {

  @PluginMethod
  fun configure(call: PluginCall) {
    val tenantId = call.getString("tenantId")
    if (tenantId.isNullOrEmpty()) {
      call.reject("InvalidTenantId", "tenantId must be a non-empty string")
      return
    }
    val baseUrl = call.getString("baseURL")
    Sammati.configure(context, tenantId, baseUrl)
    call.resolve()
  }

  @PluginMethod
  fun showBannerIfNeeded(call: PluginCall) {
    val activity = bridge.activity as? AppCompatActivity
    if (activity == null) {
      call.reject("NoActivity", "Could not resolve a host activity to present from")
      return
    }
    activity.runOnUiThread {
      Sammati.showBannerIfNeeded(activity) {
        call.resolve()
      }
    }
  }

  @PluginMethod
  fun openPreferenceCenter(call: PluginCall) {
    val activity = bridge.activity as? AppCompatActivity
    if (activity == null) {
      call.reject("NoActivity", "Could not resolve a host activity to present from")
      return
    }
    val returnUrl = call.getString("returnUrl")
    activity.runOnUiThread {
      Sammati.openPreferenceCenter(activity, returnUrl)
      call.resolve()
    }
  }

  @PluginMethod
  fun setLocale(call: PluginCall) {
    // `locale` on the JS side is `string | null`; Capacitor passes JS-null
    // through as a missing key, so getString("locale") returns null in
    // both the explicit-null and omitted cases, which is the semantic
    // we want.
    val locale = call.getString("locale")
    Sammati.setLocale(locale)
    call.resolve()
  }

  @PluginMethod
  fun getChoices(call: PluginCall) {
    val choices = Sammati.getChoices()
    val ret = JSObject()
    if (choices == null) {
      ret.put("choices", JSObject.NULL)
    } else {
      val mapped = JSObject()
      choices.forEach { (k, v) -> mapped.put(k, v) }
      ret.put("choices", mapped)
    }
    call.resolve(ret)
  }

  @PluginMethod
  fun withdraw(call: PluginCall) {
    Sammati.withdraw()
    call.resolve()
  }

  @PluginMethod
  fun reset(call: PluginCall) {
    Sammati.reset()
    call.resolve()
  }

  @PluginMethod
  fun flushOfflineQueue(call: PluginCall) {
    CoroutineScope(Dispatchers.IO).launch {
      Sammati.flushOfflineQueue()
      call.resolve()
    }
  }

  @PluginMethod
  fun getQueueDepth(call: PluginCall) {
    val ret = JSObject()
    ret.put("depth", Sammati.queueDepth)
    call.resolve(ret)
  }
}
