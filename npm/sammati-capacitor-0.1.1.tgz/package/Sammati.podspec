require 'json'

package = JSON.parse(File.read(File.join(__dir__, 'package.json')))

Pod::Spec.new do |s|
  s.name = 'SammatiCapacitor'
  s.version = package['version']
  s.summary = package['description']
  s.license = package['license']
  s.homepage = 'https://github.com/vinnzy/synapsedatalabs'
  s.author = 'Sammati'
  s.source = { :git => 'https://github.com/vinnzy/synapsedatalabs.git', :tag => s.version.to_s }
  s.source_files = 'ios/Plugin/**/*.{swift,h,m}'
  s.ios.deployment_target = '14.0'
  s.swift_version = '5.7'
  s.dependency 'Capacitor'
  # MOB-01 — the native iOS SDK we delegate to. Same pod name customers
  # consume directly when building bare iOS apps; the Capacitor plugin
  # rides on top of it rather than duplicating its 600KB of locale /
  # persistence / queue / banner UI logic.
  s.dependency 'Sammati'
end
