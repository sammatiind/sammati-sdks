// MOB-08 — Capacitor plugin for iOS. Every method delegates to the
// underlying `Sammati` SDK from packages/sdk-ios. There is intentionally
// NO logic here beyond:
//   1. Reading typed args off the CAPPluginCall.
//   2. Resolving the top view controller for present-from operations.
//   3. CAPPluginCall resolve/reject plumbing.
//
// We refuse to re-implement locale resolution, persistence, or the offline
// queue in JS — those behaviours must be identical across the four host
// platforms (bare iOS, bare Android, RN, Capacitor) and only the native
// SDK is the source of truth.

import Foundation
import Capacitor
import Sammati

@objc(SammatiPlugin)
public class SammatiPlugin: CAPPlugin {

  // ── configure ──────────────────────────────────────────────────────────

  @objc func configure(_ call: CAPPluginCall) {
    guard let tenantId = call.getString("tenantId"), !tenantId.isEmpty else {
      call.reject("InvalidTenantId", "tenantId must be a non-empty string")
      return
    }
    let baseURLString = call.getString("baseURL")
    let resolved: URL
    if let raw = baseURLString, let parsed = URL(string: raw) {
      resolved = parsed
    } else {
      resolved = RestClient.defaultBaseURL
    }
    Sammati.configure(tenantId: tenantId, baseURL: resolved)
    call.resolve()
  }

  // ── showBannerIfNeeded ─────────────────────────────────────────────────

  @objc func showBannerIfNeeded(_ call: CAPPluginCall) {
    DispatchQueue.main.async {
      guard let presenter = self.topViewController() else {
        call.reject("NoPresenter", "Could not resolve a top view controller to present from")
        return
      }
      Sammati.showBannerIfNeeded(from: presenter) {
        call.resolve()
      }
    }
  }

  // ── openPreferenceCenter ───────────────────────────────────────────────

  @objc func openPreferenceCenter(_ call: CAPPluginCall) {
    DispatchQueue.main.async {
      guard let presenter = self.topViewController() else {
        call.reject("NoPresenter", "Could not resolve a top view controller to present from")
        return
      }
      let returnUrl: URL? = call.getString("returnUrl").flatMap { URL(string: $0) }
      Sammati.openPreferenceCenter(from: presenter, returnUrl: returnUrl)
      call.resolve()
    }
  }

  // ── setLocale ──────────────────────────────────────────────────────────

  @objc func setLocale(_ call: CAPPluginCall) {
    // `locale` is explicitly `string | null` on the JS side; Capacitor
    // passes JS-null through as a missing key, so reading the optional
    // string covers both cases.
    let locale = call.getString("locale")
    Sammati.setLocale(locale)
    call.resolve()
  }

  // ── getChoices ─────────────────────────────────────────────────────────

  @objc func getChoices(_ call: CAPPluginCall) {
    let choices = Sammati.getChoices()
    // Wrap in the Capacitor convention { choices: ... } so the JS surface
    // can read `result.choices` consistently with getQueueDepth's `depth`.
    call.resolve([
      "choices": choices as Any
    ])
  }

  // ── withdraw / reset / flush ───────────────────────────────────────────

  @objc func withdraw(_ call: CAPPluginCall) {
    Sammati.withdraw()
    call.resolve()
  }

  @objc func reset(_ call: CAPPluginCall) {
    Sammati.reset()
    call.resolve()
  }

  @objc func flushOfflineQueue(_ call: CAPPluginCall) {
    Task {
      await Sammati.flushOfflineQueue()
      call.resolve()
    }
  }

  @objc func getQueueDepth(_ call: CAPPluginCall) {
    call.resolve([
      "depth": Sammati.queueDepth
    ])
  }

  // ── Helpers ────────────────────────────────────────────────────────────

  /// Walks the active scene's window hierarchy to find the topmost
  /// presented view controller. Avoids `keyWindow` (deprecated since
  /// iOS 13) and prefers the scene-based path — same pattern as
  /// @sammati/react-native's iOS bridge.
  private func topViewController() -> UIViewController? {
    let scenes = UIApplication.shared.connectedScenes
      .compactMap { $0 as? UIWindowScene }
      .filter { $0.activationState == .foregroundActive }
    let window = scenes.flatMap { $0.windows }.first(where: { $0.isKeyWindow })
      ?? scenes.flatMap { $0.windows }.first
    var top = window?.rootViewController
    while let presented = top?.presentedViewController {
      top = presented
    }
    return top
  }
}
