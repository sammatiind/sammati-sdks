// Capacitor Obj-C bridge registration. The CAP_PLUGIN macro generates the
// runtime metadata Capacitor needs to discover the plugin and its methods
// from JS. Every Swift `@objc func` that takes a CAPPluginCall must be
// declared here with its return type — Capacitor uses this to validate
// the JS bridge call before invoking the Swift method.

#import <Foundation/Foundation.h>
#import <Capacitor/Capacitor.h>

CAP_PLUGIN(SammatiPlugin, "Sammati",
  CAP_PLUGIN_METHOD(configure, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(showBannerIfNeeded, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(openPreferenceCenter, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(setLocale, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(getChoices, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(withdraw, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(reset, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(flushOfflineQueue, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(getQueueDepth, CAPPluginReturnPromise);
)
