# @sammati/capacitor

Capacitor plugin for the Sammati consent SDK. Delegates row-for-row to the
[MOB-01 iOS SDK](../sdk-ios/) and [MOB-02 Android SDK](../sdk-android/) —
no JavaScript re-implementation of locale resolution, persistence, the
offline queue, or the banner UI.

Use this package when your app is built with [Capacitor](https://capacitorjs.com/)
or [Ionic](https://ionicframework.com/). For bare React Native, use
[`@sammati/react-native`](../sdk-react-native/). For browser-only sites,
use `@sammati/banner-sdk`.

## Install

```sh
npm install @sammati/capacitor
npx cap sync
```

Capacitor's autolinking picks up the plugin from `node_modules` on the
next `cap sync`. No manual `Podfile` or `MainApplication` edits required
on RN ≥ 0.71 or Capacitor 5+.

## Quickstart

```ts
import { App } from '@capacitor/app';
import { Sammati } from '@sammati/capacitor';

// 1. Configure once at app boot.
await Sammati.configure({ tenantId: 'your-tenant-id' });

// 2. Show the banner if the user has no choices for the current notice.
await Sammati.showBannerIfNeeded();

// 3. Drain queued writes when the app comes to the foreground.
App.addListener('appStateChange', async ({ isActive }) => {
  if (isActive) await Sammati.flushOfflineQueue();
});
```

## API

| Method | Description |
| --- | --- |
| `configure({ tenantId, baseURL? })` | Configure the SDK. Validates `tenantId` synchronously. |
| `showBannerIfNeeded()` | Render the banner if no choices envelope exists for the current notice version. |
| `openPreferenceCenter({ returnUrl? })` | Open the hosted preference centre in SFSafariViewController / Chrome Custom Tab. |
| `setLocale(locale \| null)` | Override the banner locale. `null` reverts to the OS chain. |
| `getChoices()` | Read current choices; `null` on a clean install. |
| `withdraw()` | Clear choices; next `showBannerIfNeeded()` re-renders. |
| `reset()` | Wipe ALL SDK state (choices + session + queue). QA-only. |
| `flushOfflineQueue()` | Drain queued consent writes. |
| `getQueueDepth()` | Number of unflushed offline writes. |

## What is NOT in scope

- **Web**: the plugin's `SammatiWeb` fallback throws on every method. The
  banner needs OS-trust surfaces (`SFSafariViewController` / Chrome
  Custom Tabs / native modal sheets) that the web shell can't provide;
  running a faux web banner would silently break DPDP §6 informed-consent.
  Use `@sammati/banner-sdk` for browser environments.
- **Cordova**: Cordova is deprecated. Ionic / Capacitor is the supported
  path forward.

## Testing in a Capacitor app

The plugin exposes a `setPluginForTesting(mock)` helper so Vitest / Jest
suites can record bridge calls without booting a Capacitor runtime:

```ts
import { Sammati, setPluginForTesting } from '@sammati/capacitor';

setPluginForTesting({
  configure: vi.fn().mockResolvedValue(undefined),
  showBannerIfNeeded: vi.fn().mockResolvedValue(undefined),
  // ... rest of the SammatiPlugin interface
});

await Sammati.configure({ tenantId: 'demo' });
// assert on the mock
```

Call `setPluginForTesting(null)` in your teardown to revert.

## Versioning

Tracks the iOS + Android SDK versions row-for-row. Breaking changes to
the JS surface require a major bump even when the underlying native SDKs
are unchanged.

## License

Apache-2.0.
