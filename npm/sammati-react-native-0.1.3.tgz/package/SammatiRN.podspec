require 'json'
package = JSON.parse(File.read(File.join(__dir__, 'package.json')))

Pod::Spec.new do |s|
  s.name             = 'SammatiRN'
  s.version          = package['version']
  s.summary          = package['description']
  s.homepage         = 'https://github.com/vinnzy/synapsedatalabs'
  s.license          = { :type => 'Apache-2.0' }
  s.authors          = { 'Sammati' => 'noreply@sammati.io' }
  s.source           = { :git => 'https://github.com/vinnzy/synapsedatalabs.git', :tag => "v#{s.version}" }

  s.platform         = :ios, '14.0'
  s.swift_version    = '5.7'

  s.source_files     = 'ios/**/*.{h,m,mm,swift}'

  # The RN bridge delegates to the published Sammati iOS SDK. We pull it
  # from the monorepo by path so a customer who has cloned this repo can
  # build everything end-to-end without going through CocoaPods Trunk.
  # Published-to-Trunk customers will get `'Sammati', '~> 0.1'` instead
  # once we ship MOB-01's CocoaPods publication step.
  s.dependency 'Sammati'
  s.dependency 'React-Core'
end
