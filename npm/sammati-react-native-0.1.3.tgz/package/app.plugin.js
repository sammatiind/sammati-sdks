// Sammati Expo config plugin.
//
// Add it once in app.json / app.config.js:
//   { "expo": { "plugins": ["@sammati/react-native"] } }
//
// On `expo prebuild` it wires up the native SDKs the RN bridge depends on, so
// `pod install` and the Gradle sync resolve them without the customer editing
// Podfile / settings.gradle by hand:
//   • iOS     — injects the published `Sammati` pod into the Podfile (satisfies
//               the bridge's transitive `s.dependency 'Sammati'`).
//   • Android — adds the published Maven repo so `io.sammati:sdk-android` resolves.
//
// Bare (non-Expo) RN apps don't run prebuild — they add the same two lines
// manually; see the README.
const { withDangerousMod } = require('@expo/config-plugins');
const fs = require('node:fs');
const path = require('node:path');
const {
  addSammatiPod,
  addSammatiMaven,
  addSammatiMavenAllprojects,
  SAMMATI_MAVEN_URL,
} = require('./plugin/edits.js');

const withSammatiPod = (config) =>
  withDangerousMod(config, [
    'ios',
    (cfg) => {
      const podfile = path.join(cfg.modRequest.platformProjectRoot, 'Podfile');
      if (fs.existsSync(podfile)) {
        fs.writeFileSync(podfile, addSammatiPod(fs.readFileSync(podfile, 'utf8')));
      }
      return cfg;
    },
  ]);

const withSammatiMaven = (config) =>
  withDangerousMod(config, [
    'android',
    (cfg) => {
      const root = cfg.modRequest.platformProjectRoot;
      // Try, in order, the two layouts Expo templates use for the repositories
      // that resolve app dependencies:
      //   1. settings.gradle[.kts] → dependencyResolutionManagement { repositories { } }  (SDK 50+)
      //   2. build.gradle[.kts]    → allprojects { repositories { } }                       (SDK 56/RN 0.85)
      // A file that exists but lacks the block leaves its content unchanged, so
      // we fall through to the next candidate.
      const candidates = [
        ['settings.gradle.kts', true, addSammatiMaven],
        ['settings.gradle', false, addSammatiMaven],
        ['build.gradle.kts', true, addSammatiMavenAllprojects],
        ['build.gradle', false, addSammatiMavenAllprojects],
      ];
      let injected = false;
      for (const [name, kotlin, transform] of candidates) {
        const file = path.join(root, name);
        if (!fs.existsSync(file)) continue;
        const before = fs.readFileSync(file, 'utf8');
        const after = transform(before, kotlin);
        if (after !== before) {
          fs.writeFileSync(file, after);
          injected = true;
          break;
        }
      }
      if (!injected) {
        // Loud, not silent — the old bug was a no-op with no signal.
        console.warn(
          '[@sammati/react-native] Could not find a Gradle repositories block to add the ' +
            'Sammati Maven repo to (settings.gradle dependencyResolutionManagement or ' +
            'build.gradle allprojects). Add it manually so io.sammati:sdk-android resolves: ' +
            SAMMATI_MAVEN_URL,
        );
      }
      return cfg;
    },
  ]);

module.exports = (config) => withSammatiMaven(withSammatiPod(config));
