// Vitest coverage for the bridge-smoke example mock module.
//
// The example folder ships with the SDK so customer teams (starting with
// Tantu Pratha) can run a trace driver against a deterministic mock. The
// mock itself is small but load-bearing — if its call-recording or
// canned-response behaviour drifts, the trace driver gives misleading
// PASS results. These tests pin both halves.
//
// Per CLAUDE.md Testing Mandate: 1 positive + 2 negative cases.

import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { Sammati, setNativeModule } from '../index.js';
import {
  mockNative,
  calls,
  resetCalls,
} from '../../examples/bridge-smoke/mock-native.js';

beforeEach(() => {
  resetCalls();
  setNativeModule(mockNative);
});

afterEach(() => {
  setNativeModule(null);
  resetCalls();
});

describe('bridge-smoke mock-native', () => {
  // ── Positive ────────────────────────────────────────────────────────────
  it('records each Sammati call into the trace with method, args, and response', async () => {
    await Sammati.configure({
      tenantId: 'tantu-pratha',
      baseURL: 'https://api.staging.sammati.io',
    });
    const choices = await Sammati.getChoices();
    const depth = await Sammati.getQueueDepth();

    expect(choices).toEqual({ analytics: true, marketing: false });
    expect(depth).toBe(3);

    expect(calls).toHaveLength(3);
    expect(calls[0]).toMatchObject({
      method: 'configure',
      args: ['tantu-pratha', 'https://api.staging.sammati.io'],
      response: undefined,
    });
    expect(calls[1]).toMatchObject({
      method: 'getChoices',
      args: [],
      response: { analytics: true, marketing: false },
    });
    expect(calls[2]).toMatchObject({
      method: 'getQueueDepth',
      args: [],
      response: 3,
    });
    // Every recorded call has an ISO timestamp.
    for (const c of calls) {
      expect(typeof c.timestamp).toBe('string');
      expect(Number.isNaN(Date.parse(c.timestamp))).toBe(false);
    }
  });

  // ── Negative ────────────────────────────────────────────────────────────
  it('does NOT record a call when the JS-layer tenant-id validation rejects', async () => {
    await expect(Sammati.configure({ tenantId: '' })).rejects.toThrow(
      /non-empty string/,
    );
    await expect(
      Sammati.configure({ tenantId: 'bad chars!' }),
    ).rejects.toThrow(/\[a-zA-Z0-9_-\]\+/);
    await expect(
      Sammati.configure({ tenantId: 'a'.repeat(65) }),
    ).rejects.toThrow(/longer than 64/);

    expect(calls).toHaveLength(0);
  });

  it('resetCalls() clears prior recordings without breaking subsequent capture', async () => {
    await Sammati.configure({ tenantId: 'tantu-pratha' });
    expect(calls).toHaveLength(1);

    resetCalls();
    expect(calls).toHaveLength(0);

    await Sammati.withdraw();
    expect(calls).toHaveLength(1);
    expect(calls[0]).toMatchObject({ method: 'withdraw', args: [] });
  });
});
