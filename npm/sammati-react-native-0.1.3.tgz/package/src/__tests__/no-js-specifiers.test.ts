import { describe, it, expect } from 'vitest';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';

// Guard against the Metro-breaking bug class (the SammatiRN@0.1.0 blocker):
// this package ships RAW TS source (main = src/index.ts), so the consumer's
// Metro bundler resolves relative import specifiers literally. A `.js`
// specifier pointing at a file that only exists as `.ts` resolves fine under
// tsc's NodeNext remapping (so type-check passes) but throws in Metro:
//   "Unable to resolve module ./NativeSammati.js".
// A source scan is the only thing that catches it — tsc alone can't.
function tsFiles(dir: string): string[] {
  return readdirSync(dir).flatMap((name) => {
    const p = join(dir, name);
    if (statSync(p).isDirectory()) return name === '__tests__' ? [] : tsFiles(p);
    return name.endsWith('.ts') ? [p] : [];
  });
}

describe('Metro bundling guard — no .js specifiers on TS source', () => {
  it('has no relative import/export whose specifier ends in .js', () => {
    const srcDir = join(process.cwd(), 'src');
    const offenders: string[] = [];
    for (const file of tsFiles(srcDir)) {
      const matches = readFileSync(file, 'utf8').match(/from\s+['"]\.[^'"]*\.js['"]/g);
      if (matches) offenders.push(`${file}: ${matches.join(', ')}`);
    }
    expect(offenders).toEqual([]);
  });
});
