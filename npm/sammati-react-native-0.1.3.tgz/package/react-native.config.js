// React Native autolinking config.
//
// iOS: point at SammatiRN.podspec (filename matches the pod name `SammatiRN`).
//
// Android: deliberately NO explicit `platforms.android` block. RN 0.74+/0.85
// autolinking AUTO-DETECTS the Android library from `android/` and IGNORES the
// legacy `packageImportPath`/`packageInstance` keys. Worse, providing an
// explicit android block with those deprecated keys makes the new autolinking
// resolve `android: null` — so the native module is never compiled into the
// app and every SDK call silently no-ops (the banner never appears). Letting
// auto-detection run finds `SammatiRNPackage` on its own. Do not re-add it.
module.exports = {
  dependency: {
    platforms: {
      ios: {
        podspecPath: __dirname + '/SammatiRN.podspec',
      },
    },
  },
};
