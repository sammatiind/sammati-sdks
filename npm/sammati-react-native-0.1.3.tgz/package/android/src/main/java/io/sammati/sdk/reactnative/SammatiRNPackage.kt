package io.sammati.sdk.reactnative

import com.facebook.react.ReactPackage
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.uimanager.ViewManager

/**
 * Single-entry React Native package. Autolinking on RN ≥ 0.60 picks this
 * up via react-native.config.js → packageImportPath / packageInstance,
 * so the host app's MainApplication does NOT need to add it manually.
 */
class SammatiRNPackage : ReactPackage {

    override fun createNativeModules(reactContext: ReactApplicationContext): List<NativeModule> =
        listOf(SammatiRNModule(reactContext))

    override fun createViewManagers(reactContext: ReactApplicationContext): List<ViewManager<*, *>> =
        emptyList()
}
