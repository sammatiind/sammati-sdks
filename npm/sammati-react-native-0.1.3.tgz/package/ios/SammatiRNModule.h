// SammatiRNModule.h — Objective-C header so React Native's bridge can
// resolve the module from JavaScript. The implementation is split:
//   - SammatiRNModule.m  — RCT_EXTERN_MODULE / RCT_EXTERN_METHOD declarations
//   - SammatiRNModule.swift — actual logic delegating to the Sammati iOS SDK
//
// We use the bridging pattern (not Swift @objc(RCT...) alone) because it
// stays portable across RN ≥ 0.71 without requiring TurboModules codegen.

#import <React/RCTBridgeModule.h>
