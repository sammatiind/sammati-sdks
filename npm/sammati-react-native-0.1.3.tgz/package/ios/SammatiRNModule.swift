// MOB-03 — React Native bridge for iOS. Every method delegates to the
// underlying `Sammati` SDK from packages/sdk-ios. There is intentionally
// NO logic here beyond:
//   1. Arg unwrapping (NSString → String, NSNull → nil).
//   2. Resolving the top view controller for present-from operations.
//   3. Promise resolve/reject plumbing.
//
// Re-implementing locale resolution, persistence, or the offline queue
// in JS would let the four host platforms (bare iOS, bare Android, RN,
// Capacitor) drift on UX-compliance corner cases. We refuse to do that.

import Foundation
import UIKit
import Sammati

@objc(SammatiRN)
final class SammatiRNModule: NSObject {

  @objc static func requiresMainQueueSetup() -> Bool { true }

  // ── configure ──────────────────────────────────────────────────────────

  @objc(configure:baseURL:resolver:rejecter:)
  func configure(
    _ tenantId: String,
    baseURL: NSString?,
    resolver resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    let urlOrDefault: URL
    if let raw = baseURL as String?, let parsed = URL(string: raw) {
      urlOrDefault = parsed
    } else {
      urlOrDefault = RestClient.defaultBaseURL
    }
    Sammati.configure(tenantId: tenantId, baseURL: urlOrDefault)
    resolve(nil)
  }

  // ── showBannerIfNeeded ─────────────────────────────────────────────────

  @objc(showBannerIfNeeded:rejecter:)
  func showBannerIfNeeded(
    _ resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    DispatchQueue.main.async {
      guard let presenter = self.topViewController() else {
        reject("NoPresenter", "Could not resolve a top view controller to present from", nil)
        return
      }
      Sammati.showBannerIfNeeded(from: presenter) {
        resolve(nil)
      }
    }
  }

  // ── openPreferenceCenter ───────────────────────────────────────────────

  @objc(openPreferenceCenter:resolver:rejecter:)
  func openPreferenceCenter(
    _ returnUrl: NSString?,
    resolver resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    DispatchQueue.main.async {
      guard let presenter = self.topViewController() else {
        reject("NoPresenter", "Could not resolve a top view controller to present from", nil)
        return
      }
      let url: URL? = (returnUrl as String?).flatMap { URL(string: $0) }
      Sammati.openPreferenceCenter(from: presenter, returnUrl: url)
      resolve(nil)
    }
  }

  // ── setLocale ──────────────────────────────────────────────────────────

  @objc(setLocale:resolver:rejecter:)
  func setLocale(
    _ locale: NSString?,
    resolver resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    Sammati.setLocale(locale as String?)
    resolve(nil)
  }

  // ── getChoices ─────────────────────────────────────────────────────────

  @objc(getChoices:rejecter:)
  func getChoices(
    _ resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    let choices = Sammati.getChoices()
    resolve(choices) // NSNull bridges to JS null when nil
  }

  // ── withdraw / reset / flush ───────────────────────────────────────────

  @objc(withdraw:rejecter:)
  func withdraw(
    _ resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    Sammati.withdraw()
    resolve(nil)
  }

  @objc(reset:rejecter:)
  func reset(
    _ resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    Sammati.reset()
    resolve(nil)
  }

  @objc(flushOfflineQueue:rejecter:)
  func flushOfflineQueue(
    _ resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    Task {
      await Sammati.flushOfflineQueue()
      resolve(nil)
    }
  }

  @objc(getQueueDepth:rejecter:)
  func getQueueDepth(
    _ resolve: @escaping RCTPromiseResolveBlock,
    rejecter reject: @escaping RCTPromiseRejectBlock
  ) {
    resolve(Sammati.queueDepth)
  }

  // ── Helpers ────────────────────────────────────────────────────────────

  /// Walks the active scene's window hierarchy to find the topmost
  /// presented view controller. We avoid `keyWindow` (deprecated since
  /// iOS 13) and prefer the scene-based path.
  private func topViewController() -> UIViewController? {
    let scenes = UIApplication.shared.connectedScenes
      .compactMap { $0 as? UIWindowScene }
      .filter { $0.activationState == .foregroundActive }
    let window = scenes.flatMap { $0.windows }.first(where: { $0.isKeyWindow })
      ?? scenes.flatMap { $0.windows }.first
    var top = window?.rootViewController
    while let presented = top?.presentedViewController {
      top = presented
    }
    return top
  }
}
