import Foundation

/// Wire shape of `GET /v1/mobile-config/:tenantId`. Mirrors the Zod schema
/// at `services/core-api/src/modules/m10-mobile-sdk/mobile-config.schema.ts`.
///
/// `Decodable` only — the SDK never POSTs this shape, so we don't pay for
/// the `Encodable` synthesis.
public struct MobileConfig: Decodable, Equatable {
    public let tenantId: String
    public let noticeVersion: String
    public let publishedAt: String?
    public let languageFallbackChain: [String]
    public let purposes: [Purpose]
    public let grievanceOfficer: GrievanceOfficer
    public let bundleIdAllowlist: [String]
    public let attestationRequired: Bool

    public struct Purpose: Decodable, Equatable {
        public let purposeId: String
        public let code: String
        public let basis: Basis
        public let labelI18n: [String: String]
        public let descriptionI18n: [String: String]
        public let sensitive: Bool
        public let defaultState: Bool

        public enum Basis: String, Decodable, Equatable {
            case consent
            case legitimateUse = "legitimate_use"
            case contractual
            case legalObligation = "legal_obligation"
        }

        enum CodingKeys: String, CodingKey {
            case purposeId = "purpose_id"
            case code
            case basis
            case labelI18n = "label_i18n"
            case descriptionI18n = "description_i18n"
            case sensitive
            case defaultState = "default_state"
        }
    }

    public struct GrievanceOfficer: Decodable, Equatable {
        public let name: String?
        public let emailMasked: String?
        public let phoneMasked: String?

        enum CodingKeys: String, CodingKey {
            case name
            case emailMasked = "email_masked"
            case phoneMasked = "phone_masked"
        }
    }

    enum CodingKeys: String, CodingKey {
        case tenantId = "tenant_id"
        case noticeVersion = "notice_version"
        case publishedAt = "published_at"
        case languageFallbackChain = "language_fallback_chain"
        case purposes
        case grievanceOfficer = "grievance_officer"
        case bundleIdAllowlist = "bundle_id_allowlist"
        case attestationRequired = "attestation_required"
    }
}
