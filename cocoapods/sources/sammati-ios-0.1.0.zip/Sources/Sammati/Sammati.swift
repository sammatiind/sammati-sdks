import Foundation
#if canImport(UIKit)
import UIKit
#endif
#if canImport(SwiftUI)
import SwiftUI
#endif
#if canImport(SafariServices)
import SafariServices
#endif

/// Public entry point of the Sammati iOS SDK.
///
/// Mirrors the browser banner SDK at `packages/banner-sdk/src/index.ts` — no
/// API key, stateless config-driven, hits only `/v1/banner/public/...` and
/// `/v1/mobile-config/...` routes. The host app calls `configure(...)` once
/// in `application(_:didFinishLaunchingWithOptions:)`, then either lets
/// `showBannerIfNeeded()` decide whether to surface the banner or wires up
/// its own settings-screen entry to `openPreferenceCenter(returnUrl:)`.
///
/// Thread safety: all mutators dispatch onto an internal serial queue so
/// the public API is callable from any thread, including the main thread
/// during view lifecycle methods.
public final class Sammati {

    public static let shared = Sammati()

    private let queue = DispatchQueue(label: "io.sammati.sdk", qos: .userInitiated)
    private var configuration: Configuration?
    private var cachedConfig: MobileConfig?
    private var explicitLocale: String?
    private let persistence: Persistence
    private let queueStorage: OfflineQueue
    private var client: RestClient?

    /// Visible-for-test init — production code uses `Sammati.shared`. The
    /// parameters here let `SammatiTests` plug in scoped persistence so
    /// parallel XCTest runs don't trample one another.
    init(persistence: Persistence = Persistence(),
         offlineQueue: OfflineQueue = OfflineQueue()) {
        self.persistence = persistence
        self.queueStorage = offlineQueue
    }

    // ── Configuration ─────────────────────────────────────────────────────

    public struct Configuration {
        public let tenantId: String
        public let baseURL: URL

        public init(tenantId: String, baseURL: URL = RestClient.defaultBaseURL) {
            self.tenantId = tenantId
            self.baseURL = baseURL
        }
    }

    /// MUST be called before any other API. Safe to call multiple times —
    /// the last call wins, which is convenient for app extensions that
    /// inherit a parent process's already-configured SDK.
    public static func configure(tenantId: String, baseURL: URL = RestClient.defaultBaseURL) {
        shared.queue.sync {
            shared.configuration = Configuration(tenantId: tenantId, baseURL: baseURL)
            shared.client = RestClient(baseURL: baseURL)
        }
    }

    // ── Locale override ───────────────────────────────────────────────────

    /// FR-MOB-02 explicit override. Pass nil to revert to OS-language
    /// resolution. The override is in-memory only; we do NOT persist it so
    /// a relaunch reverts to OS preference unless the app sets it again.
    public static func setLocale(_ locale: String?) {
        shared.queue.sync { shared.explicitLocale = locale }
    }

    // ── Choices ───────────────────────────────────────────────────────────

    public static func getChoices() -> [String: Bool]? {
        return shared.persistence.loadChoices()?.choices
    }

    /// FR-MOB-06 — withdraw. Clears the stored choice envelope so the next
    /// `showBannerIfNeeded()` returns the banner. Does NOT send a server
    /// write; the next interaction does that.
    public static func withdraw() {
        shared.persistence.clearChoices()
    }

    /// FR-MOB-13 — hard reset (for QA / sample-app demo flow). Wipes both
    /// the choice envelope AND the Keychain session id so the next launch
    /// looks like a fresh install.
    public static func reset() {
        shared.persistence.clearChoices()
        shared.persistence.clearSessionId()
        shared.queueStorage.clear()
    }

    // ── Banner ────────────────────────────────────────────────────────────

    /// FR-MOB-01 — render the banner ONLY if (a) no choices stored or
    /// (b) the stored `noticeVersion` is older than the published version
    /// (FR-MOB-05 re-consent on notice bump).
    ///
    /// Returns `true` if the banner was presented. The completion fires
    /// once the user makes a choice OR the banner is dismissed.
    #if canImport(UIKit) && canImport(SwiftUI)
    @discardableResult
    public static func showBannerIfNeeded(
        from presenter: UIViewController,
        completion: (() -> Void)? = nil
    ) -> Bool {
        guard let config = shared.configuration, let client = shared.client else {
            assertionFailure("Sammati.configure(...) must be called before showBannerIfNeeded")
            return false
        }

        // Fire-and-forget the config fetch; if we already have a stored
        // choice for the latest notice version we can short-circuit.
        Task { @MainActor in
            let mobileConfig: MobileConfig
            do {
                mobileConfig = try await client.fetchMobileConfig(tenantId: config.tenantId)
            } catch {
                completion?()
                return
            }

            shared.queue.sync { shared.cachedConfig = mobileConfig }

            // Skip if already consented to current notice version.
            if let stored = shared.persistence.loadChoices(),
               stored.noticeVersion == mobileConfig.noticeVersion {
                completion?()
                return
            }

            // Resolve locale. If nothing in the fallback chain is
            // available we surface `.localeUnavailable` via completion's
            // side channel — host apps that care should call
            // `setLocale(...)` explicitly. We do NOT render English.
            let resolved = LocaleResolver.resolve(
                explicitOverride: shared.explicitLocale,
                osPreferredLanguages: Locale.preferredLanguages,
                fallbackChain: mobileConfig.languageFallbackChain,
                availableLocales: shared.availableLocaleSet(from: mobileConfig)
            )

            guard let locale = resolved else {
                completion?()
                return
            }

            let view = BannerSheetView(config: mobileConfig, locale: locale) { interaction, choices in
                shared.persistChoiceAndWrite(
                    interaction: interaction,
                    choices: choices,
                    config: mobileConfig
                )
                presenter.dismiss(animated: true) { completion?() }
            }
            let host = UIHostingController(rootView: view)
            host.modalPresentationStyle = .formSheet
            presenter.present(host, animated: true)

            shared.fireImpression(
                client: client,
                tenantId: config.tenantId,
                bannerShown: true,
                bannerVersion: mobileConfig.noticeVersion,
                language: locale
            )
        }
        return true
    }
    #endif

    // ── Preference centre (Safari) ────────────────────────────────────────

    #if canImport(SafariServices) && canImport(UIKit)
    /// FR-MOB-11 — opens the hosted preference centre in
    /// `SFSafariViewController`. We deliberately do NOT embed the prefs
    /// flow as native UI: OTP entry, audit-row display and ledger-receipt
    /// rendering are owned by the web layer to keep parity.
    public static func openPreferenceCenter(from presenter: UIViewController, returnUrl: URL? = nil) {
        guard let config = shared.configuration else {
            assertionFailure("Sammati.configure(...) must be called before openPreferenceCenter")
            return
        }
        var components = URLComponents(url: config.baseURL, resolvingAgainstBaseURL: false)
        components?.path = "/prefs/\(config.tenantId)"
        if let returnUrl = returnUrl {
            components?.queryItems = [URLQueryItem(name: "return_url", value: returnUrl.absoluteString)]
        }
        guard let url = components?.url else { return }
        let safari = SFSafariViewController(url: url)
        presenter.present(safari, animated: true)
    }
    #endif

    // ── Internals ─────────────────────────────────────────────────────────

    private func availableLocaleSet(from config: MobileConfig) -> Set<String> {
        var locales: Set<String> = []
        for p in config.purposes {
            for k in p.labelI18n.keys { locales.insert(k) }
        }
        return locales
    }

    private func persistChoiceAndWrite(
        interaction: ConsentWriteBody.InteractionType,
        choices: [String: Bool],
        config: MobileConfig
    ) {
        persistence.storeChoices(choices, noticeVersion: config.noticeVersion)

        guard let cfg = configuration, let client = self.client else { return }
        let sessionId = persistence.loadOrCreateSessionId()
        let device = DeviceMetadata.current()
        let key = IdempotencyKey.derive(
            sessionId: sessionId,
            noticeVersion: config.noticeVersion,
            choices: choices
        )
        let body = ConsentWriteBody(
            sessionId: sessionId,
            bannerVersion: config.noticeVersion,
            language: explicitLocale ?? (Locale.preferredLanguages.first ?? "en"),
            interactionType: interaction,
            choices: choices,
            collectionMethod: "mobile_app",
            appBundleId: device.appBundleId,
            appVersion: device.appVersion,
            os: device.os,
            osVersion: device.osVersion,
            deviceModel: device.deviceModel,
            delayedWrite: false
        )

        Task {
            do {
                try await client.postConsent(tenantId: cfg.tenantId, body: body, idempotencyKey: key)
            } catch {
                // Offline / 5xx — enqueue for replay. If the queue is at
                // its 10-deep ceiling we silently drop here (the closed
                // error set surfaces `.queueOverflow` for callers that
                // want to inspect via `Sammati.queueDepth`).
                let entry = OfflineQueue.Entry(
                    tenantId: cfg.tenantId,
                    body: ConsentWriteBody(
                        sessionId: body.sessionId,
                        bannerVersion: body.bannerVersion,
                        language: body.language,
                        interactionType: body.interactionType,
                        choices: body.choices,
                        collectionMethod: body.collectionMethod,
                        appBundleId: body.appBundleId,
                        appVersion: body.appVersion,
                        os: body.os,
                        osVersion: body.osVersion,
                        deviceModel: body.deviceModel,
                        delayedWrite: true
                    ),
                    idempotencyKey: key,
                    enqueuedAt: Date()
                )
                _ = try? queueStorage.enqueue(entry)
            }
        }
    }

    private func fireImpression(
        client: RestClient,
        tenantId: String,
        bannerShown: Bool,
        bannerVersion: String,
        language: String
    ) {
        let sessionId = persistence.loadOrCreateSessionId()
        Task {
            let body = ImpressionBody(
                sessionId: sessionId,
                bannerShown: bannerShown,
                bannerVersion: bannerVersion,
                language: language
            )
            try? await client.postImpression(tenantId: tenantId, body: body)
        }
    }

    // ── Diagnostics ───────────────────────────────────────────────────────

    public static var queueDepth: Int { shared.queueStorage.depth }

    /// Drains the offline queue. Host apps call this on
    /// `applicationDidBecomeActive` or after reachability flips to online.
    public static func flushOfflineQueue() async {
        guard let client = shared.client else { return }
        for entry in shared.queueStorage.peekAll() {
            do {
                try await client.postConsent(
                    tenantId: entry.tenantId,
                    body: entry.body,
                    idempotencyKey: entry.idempotencyKey
                )
                shared.queueStorage.remove(idempotencyKey: entry.idempotencyKey)
            } catch {
                // Stop on first failure — preserves order, retry on next
                // flush opportunity.
                return
            }
        }
    }
}
