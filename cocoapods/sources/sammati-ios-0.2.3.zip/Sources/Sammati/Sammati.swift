import Foundation
#if canImport(UIKit)
import UIKit
#endif
#if canImport(SwiftUI)
import SwiftUI
#endif
#if canImport(SafariServices)
import SafariServices
#endif

/// Public entry point of the Sammati iOS SDK.
///
/// Mirrors the browser banner SDK at `packages/banner-sdk/src/index.ts` — no
/// API key, stateless config-driven, hits only `/v1/banner/public/...` and
/// `/v1/mobile-config/...` routes. The host app calls `configure(...)` once
/// in `application(_:didFinishLaunchingWithOptions:)`, then either lets
/// `showBannerIfNeeded()` decide whether to surface the banner or wires up
/// its own settings-screen entry to `openPreferenceCenter(returnUrl:)`.
///
/// Thread safety: all mutators dispatch onto an internal serial queue so
/// the public API is callable from any thread, including the main thread
/// during view lifecycle methods.
public final class Sammati {

    public static let shared = Sammati()

    private let queue = DispatchQueue(label: "io.sammati.sdk", qos: .userInitiated)
    private var configuration: Configuration?
    private var cachedConfig: MobileConfig?
    private var explicitLocale: String?
    private let persistence: Persistence
    private let queueStorage: OfflineQueue
    private var client: RestClient?

    /// Visible-for-test init — production code uses `Sammati.shared`. The
    /// parameters here let `SammatiTests` plug in scoped persistence so
    /// parallel XCTest runs don't trample one another.
    init(persistence: Persistence = Persistence(),
         offlineQueue: OfflineQueue = OfflineQueue()) {
        self.persistence = persistence
        self.queueStorage = offlineQueue
    }

    // ── Configuration ─────────────────────────────────────────────────────

    /// Default host of the hosted preference-center SPA. A SEPARATE domain
    /// from the API base — the preference centre is a web app, not an API
    /// route, so it must NOT be derived from `baseURL` (doing so opened
    /// `https://api.sammati.io/prefs/<tenant>`, which 404s). White-label /
    /// BYOC apps override via `configure(preferenceCenterURL:)`.
    /// See documentation/integrations/manage-privacy-link.md.
    public static let defaultPreferenceCenterURL = URL(string: "https://privacy.sammati.io")!

    public struct Configuration {
        public let tenantId: String
        public let baseURL: URL
        public let preferenceCenterURL: URL

        public init(
            tenantId: String,
            baseURL: URL = RestClient.defaultBaseURL,
            preferenceCenterURL: URL = Sammati.defaultPreferenceCenterURL
        ) {
            self.tenantId = tenantId
            self.baseURL = baseURL
            self.preferenceCenterURL = preferenceCenterURL
        }
    }

    /// MUST be called before any other API. Safe to call multiple times —
    /// the last call wins, which is convenient for app extensions that
    /// inherit a parent process's already-configured SDK.
    ///
    /// - Parameter preferenceCenterURL: base URL of the hosted preference
    ///   centre opened by `openPreferenceCenter`. Defaults to the Sammati SaaS
    ///   host; set it for a white-label custom domain or a BYOC deployment.
    public static func configure(
        tenantId: String,
        baseURL: URL = RestClient.defaultBaseURL,
        preferenceCenterURL: URL = Sammati.defaultPreferenceCenterURL
    ) {
        shared.queue.sync {
            shared.configuration = Configuration(
                tenantId: tenantId,
                baseURL: baseURL,
                preferenceCenterURL: preferenceCenterURL
            )
            shared.client = RestClient(baseURL: baseURL)
        }
    }

    // ── Locale override ───────────────────────────────────────────────────

    /// FR-MOB-02 explicit override. Pass nil to revert to OS-language
    /// resolution. The override is in-memory only; we do NOT persist it so
    /// a relaunch reverts to OS preference unless the app sets it again.
    public static func setLocale(_ locale: String?) {
        shared.queue.sync { shared.explicitLocale = locale }
    }

    // ── Choices ───────────────────────────────────────────────────────────

    public static func getChoices() -> [String: Bool]? {
        return shared.persistence.loadChoices()?.choices
    }

    /// FR-MOB-06 — withdraw. Clears the stored choice envelope so the next
    /// `showBannerIfNeeded()` returns the banner. Does NOT send a server
    /// write; the next interaction does that.
    public static func withdraw() {
        shared.persistence.clearChoices()
    }

    /// FR-MOB-13 — hard reset (for QA / sample-app demo flow). Wipes both
    /// the choice envelope AND the Keychain session id so the next launch
    /// looks like a fresh install.
    public static func reset() {
        shared.persistence.clearChoices()
        shared.persistence.clearAllFormState()
        shared.persistence.clearSessionId()
        shared.queueStorage.clear()
    }

    // ── Banner ────────────────────────────────────────────────────────────

    /// FR-MOB-01 — render the banner ONLY if (a) no choices stored or
    /// (b) the stored `noticeVersion` is older than the published version
    /// (FR-MOB-05 re-consent on notice bump).
    ///
    /// Returns `true` if the banner was presented. The completion fires
    /// once the user makes a choice OR the banner is dismissed.
    #if canImport(UIKit) && canImport(SwiftUI)
    @discardableResult
    public static func showBannerIfNeeded(
        from presenter: UIViewController,
        completion: (() -> Void)? = nil
    ) -> Bool {
        guard let config = shared.configuration, let client = shared.client else {
            assertionFailure("Sammati.configure(...) must be called before showBannerIfNeeded")
            return false
        }

        // Fire-and-forget the config fetch; if we already have a stored
        // choice for the latest notice version we can short-circuit.
        Task { @MainActor in
            let mobileConfig: MobileConfig
            do {
                mobileConfig = try await client.fetchMobileConfig(tenantId: config.tenantId)
            } catch {
                completion?()
                return
            }

            shared.queue.sync { shared.cachedConfig = mobileConfig }

            // Skip if already consented to current notice version.
            if let stored = shared.persistence.loadChoices(),
               stored.noticeVersion == mobileConfig.noticeVersion {
                completion?()
                return
            }

            // Resolve locale. If nothing in the fallback chain is
            // available we surface `.localeUnavailable` via completion's
            // side channel — host apps that care should call
            // `setLocale(...)` explicitly. We do NOT render English.
            let resolved = LocaleResolver.resolve(
                explicitOverride: shared.explicitLocale,
                osPreferredLanguages: Locale.preferredLanguages,
                fallbackChain: mobileConfig.languageFallbackChain,
                availableLocales: shared.availableLocaleSet(from: mobileConfig)
            )

            guard let locale = resolved else {
                completion?()
                return
            }

            let view = BannerSheetView(config: mobileConfig, locale: locale) { interaction, choices in
                shared.persistChoiceAndWrite(
                    interaction: interaction,
                    choices: choices,
                    config: mobileConfig
                )
                presenter.dismiss(animated: true) { completion?() }
            }
            let host = UIHostingController(rootView: view)
            host.modalPresentationStyle = .formSheet
            presenter.present(host, animated: true)

            shared.fireImpression(
                client: client,
                tenantId: config.tenantId,
                bannerShown: true,
                bannerVersion: mobileConfig.noticeVersion,
                language: locale
            )
        }
        return true
    }
    #endif

    // ── Preference centre (Safari) ────────────────────────────────────────

    #if canImport(SafariServices) && canImport(UIKit)
    /// FR-MOB-11 — opens the hosted preference centre in
    /// `SFSafariViewController`. We deliberately do NOT embed the prefs
    /// flow as native UI: OTP entry, audit-row display and ledger-receipt
    /// rendering are owned by the web layer to keep parity.
    public static func openPreferenceCenter(from presenter: UIViewController, returnUrl: URL? = nil) {
        guard let config = shared.configuration else {
            assertionFailure("Sammati.configure(...) must be called before openPreferenceCenter")
            return
        }
        // The preference centre is the hosted SPA on its own domain, reached as
        // `${preferenceCenterURL}/?tenant=…` — NOT `${baseURL}/prefs/<tenant>`
        // (the API host has no such route and returns 404).
        var components = URLComponents(url: config.preferenceCenterURL, resolvingAgainstBaseURL: false)
        components?.path = "/"
        var items = [URLQueryItem(name: "tenant", value: config.tenantId)]
        if let returnUrl = returnUrl {
            items.append(URLQueryItem(name: "return_url", value: returnUrl.absoluteString))
        }
        components?.queryItems = items
        guard let url = components?.url else { return }
        let safari = SFSafariViewController(url: url)
        presenter.present(safari, animated: true)
    }
    #endif

    // ── Server-driven per-form consent (F10.10) ───────────────────────────
    //
    // Mirrors the Android SDK row-for-row. Each app PII form is instrumented
    // under a stable `formKey`; the org maps a notice + purposes to it in the
    // /pii-forms portal, and these record consent against the same backend the
    // web form-consent flow uses.

    /// Published consent mapping for a single app form. The host app renders
    /// its own native consent UI from this; `basis` is the wire string.
    public struct FormConsentSpec: Equatable {
        public let formKey: String
        public let uxMode: String
        public let purposes: [Purpose]
        public let notice: Notice?

        public struct Purpose: Equatable {
            public let code: String
            public let basis: String
            public let required: Bool
            public let labelI18n: [String: String]
        }
        public struct Notice: Equatable {
            public let id: String
            public let version: Int
            public let defaultLanguage: String
            public let contents: [Content]
        }
        public struct Content: Equatable {
            public let language: String
            public let title: String
            public let body: String
            public let shortDescription: String
        }
    }

    /// Fetch the published mapping for `formKey`, or nil if the admin hasn't
    /// mapped it yet. The host app renders its own toggles from the result.
    public static func getFormConsent(formKey: String) async throws -> FormConsentSpec? {
        guard let cfg = shared.configuration, let client = shared.client else {
            throw SammatiError.notConfigured
        }
        let config = try await client.fetchMobileConfig(tenantId: cfg.tenantId)
        shared.queue.sync { shared.cachedConfig = config }
        guard let mapping = config.forms.first(where: { $0.formKey == formKey }) else { return nil }
        return Sammati.spec(from: mapping)
    }

    /// Record the user's consent on `formKey` at form submit. `consentedPurposes`
    /// is the subset of the mapping's purposes the user agreed to; `principalId`
    /// is the form's identifier (email / phone) or nil for anonymous.
    public static func recordFormConsent(
        formKey: String,
        consentedPurposes: [String],
        principalId: String? = nil
    ) async throws {
        guard let cfg = shared.configuration, let client = shared.client else {
            throw SammatiError.notConfigured
        }
        let config = try await client.fetchMobileConfig(tenantId: cfg.tenantId)
        let mapping = config.forms.first(where: { $0.formKey == formKey })
        let locale = shared.explicitLocale
            ?? Locale.preferredLanguages.first
            ?? config.languageFallbackChain.first
        let body = FormConsentBody(
            fingerprint: formKey,
            purposes: consentedPurposes,
            principalId: principalId,
            formAction: nil,
            pageUrl: "app://\(formKey)",
            collectionMethod: "form_submit",
            affirmativeAction: "checkbox_submit",
            noticeId: mapping?.notice?.id,
            noticeVersion: mapping?.notice?.version,
            uiLocale: locale,
            bannerVersion: config.noticeVersion,
            degraded: nil
        )
        try await client.postFormConsent(tenantId: cfg.tenantId, body: body)

        // Reflect the outcome in the local per-purpose choices so getChoices()
        // — and the host app's "already consented?" check — sees form-given
        // consent too (not just banner choices). granted = in consentedPurposes.
        // noticeVersion is preserved so this never affects banner re-prompt gating.
        if let m = mapping {
            let existing = shared.persistence.loadChoices()
            var merged = existing?.choices ?? [:]
            for p in m.purposes { merged[p.code] = consentedPurposes.contains(p.code) }
            shared.persistence.storeChoices(merged, noticeVersion: existing?.noticeVersion ?? "")
        }

        // Record per-form state so the next formConsentState() for this
        // principal+form at this notice version is answered locally (no call).
        if let pid = principalId, let v = mapping?.notice?.version {
            shared.persistence.storeFormState(formKey: formKey, principalId: pid, noticeVersion: v)
        }
    }

    /// Whether a data principal still needs to consent to a form.
    public enum FormConsentStatus: String, Equatable {
        case consented
        case needsConsent
        case unmapped
    }

    /// Result of `formConsentState`: the status plus the form's current notice
    /// version (nil when the form isn't mapped / has no published notice).
    public struct FormConsentState: Equatable {
        public let status: FormConsentStatus
        public let noticeVersion: Int?
    }

    /// Whether `principalId` has already consented to `formKey` at its CURRENT
    /// notice version — so the host app can show the consent form or a "you've
    /// already agreed" view. Re-surfaces consent for one-time flows (e.g.
    /// signup) that never re-render on their own.
    ///
    /// Local-first: if a prior `recordFormConsent` (or status check) for this
    /// principal+form at the current notice version is cached on device,
    /// returns `.consented` with NO per-principal network call. Otherwise it
    /// asks the server once and caches the result.
    public static func formConsentState(
        formKey: String,
        principalId: String
    ) async throws -> FormConsentState {
        guard let cfg = shared.configuration, let client = shared.client else {
            throw SammatiError.notConfigured
        }
        let config = try await client.fetchMobileConfig(tenantId: cfg.tenantId)
        guard let currentVersion = config.forms.first(where: { $0.formKey == formKey })?.notice?.version else {
            return FormConsentState(status: .unmapped, noticeVersion: nil)
        }

        // Local-first: prior consent for this exact notice version → no call.
        if shared.persistence.loadFormStateNoticeVersion(formKey: formKey, principalId: principalId) == currentVersion {
            return FormConsentState(status: .consented, noticeVersion: currentVersion)
        }

        // Cache-miss / notice drift → ask the server once, then cache.
        let resp = try await client.postFormConsentStatus(tenantId: cfg.tenantId, fingerprint: formKey, principalId: principalId)
        let status: FormConsentStatus
        switch resp.status {
        case "consented": status = .consented
        case "unmapped":  status = .unmapped
        default:          status = .needsConsent
        }
        let version = resp.noticeVersion ?? currentVersion
        if status == .consented {
            shared.persistence.storeFormState(formKey: formKey, principalId: principalId, noticeVersion: version)
        }
        return FormConsentState(status: status, noticeVersion: version)
    }

    /// Register an app form by its field names so it self-registers in the
    /// portal's App tab for an admin to map. Best-effort; safe on every view.
    public static func discoverForm(formKey: String, fields: [String]) async throws {
        guard let cfg = shared.configuration, let client = shared.client else {
            throw SammatiError.notConfigured
        }
        let body = DiscoverFormBody(
            version: 1,
            bannerVersion: nil,
            fingerprint: formKey,
            selector: formKey,
            action: nil,
            pageUrl: "app://\(formKey)",
            fields: fields.map {
                DiscoverFormBody.Field(name: $0, htmlType: nil, placeholder: nil, label: nil, required: false, autocomplete: nil)
            }
        )
        try await client.postDiscoverForm(tenantId: cfg.tenantId, body: body)
    }

    private static func spec(from m: MobileConfig.FormMapping) -> FormConsentSpec {
        FormConsentSpec(
            formKey: m.formKey,
            uxMode: m.uxMode,
            purposes: m.purposes.map {
                FormConsentSpec.Purpose(code: $0.code, basis: $0.basis.rawValue, required: $0.required, labelI18n: $0.labelI18n)
            },
            notice: m.notice.map { n in
                FormConsentSpec.Notice(
                    id: n.id,
                    version: n.version,
                    defaultLanguage: n.defaultLanguage,
                    contents: n.contents.map {
                        FormConsentSpec.Content(language: $0.language, title: $0.title, body: $0.body, shortDescription: $0.shortDescription)
                    }
                )
            }
        )
    }

    // ── Internals ─────────────────────────────────────────────────────────

    private func availableLocaleSet(from config: MobileConfig) -> Set<String> {
        var locales: Set<String> = []
        for p in config.purposes {
            for k in p.labelI18n.keys { locales.insert(k) }
        }
        return locales
    }

    private func persistChoiceAndWrite(
        interaction: ConsentWriteBody.InteractionType,
        choices: [String: Bool],
        config: MobileConfig
    ) {
        persistence.storeChoices(choices, noticeVersion: config.noticeVersion)

        guard let cfg = configuration, let client = self.client else { return }
        let sessionId = persistence.loadOrCreateSessionId()
        let device = DeviceMetadata.current()
        let key = IdempotencyKey.derive(
            sessionId: sessionId,
            noticeVersion: config.noticeVersion,
            choices: choices
        )
        let body = ConsentWriteBody(
            sessionId: sessionId,
            bannerVersion: config.noticeVersion,
            language: explicitLocale ?? (Locale.preferredLanguages.first ?? "en"),
            interactionType: interaction,
            choices: choices,
            collectionMethod: "mobile_app",
            appBundleId: device.appBundleId,
            appVersion: device.appVersion,
            os: device.os,
            osVersion: device.osVersion,
            deviceModel: device.deviceModel,
            delayedWrite: false
        )

        Task {
            do {
                try await client.postConsent(tenantId: cfg.tenantId, body: body, idempotencyKey: key)
            } catch {
                // Offline / 5xx — enqueue for replay. If the queue is at
                // its 10-deep ceiling we silently drop here (the closed
                // error set surfaces `.queueOverflow` for callers that
                // want to inspect via `Sammati.queueDepth`).
                let entry = OfflineQueue.Entry(
                    tenantId: cfg.tenantId,
                    body: ConsentWriteBody(
                        sessionId: body.sessionId,
                        bannerVersion: body.bannerVersion,
                        language: body.language,
                        interactionType: body.interactionType,
                        choices: body.choices,
                        collectionMethod: body.collectionMethod,
                        appBundleId: body.appBundleId,
                        appVersion: body.appVersion,
                        os: body.os,
                        osVersion: body.osVersion,
                        deviceModel: body.deviceModel,
                        delayedWrite: true
                    ),
                    idempotencyKey: key,
                    enqueuedAt: Date()
                )
                _ = try? queueStorage.enqueue(entry)
            }
        }
    }

    private func fireImpression(
        client: RestClient,
        tenantId: String,
        bannerShown: Bool,
        bannerVersion: String,
        language: String
    ) {
        let sessionId = persistence.loadOrCreateSessionId()
        Task {
            let body = ImpressionBody(
                sessionId: sessionId,
                bannerShown: bannerShown,
                bannerVersion: bannerVersion,
                language: language
            )
            try? await client.postImpression(tenantId: tenantId, body: body)
        }
    }

    // ── Diagnostics ───────────────────────────────────────────────────────

    public static var queueDepth: Int { shared.queueStorage.depth }

    /// Drains the offline queue. Host apps call this on
    /// `applicationDidBecomeActive` or after reachability flips to online.
    public static func flushOfflineQueue() async {
        guard let client = shared.client else { return }
        for entry in shared.queueStorage.peekAll() {
            do {
                try await client.postConsent(
                    tenantId: entry.tenantId,
                    body: entry.body,
                    idempotencyKey: entry.idempotencyKey
                )
                shared.queueStorage.remove(idempotencyKey: entry.idempotencyKey)
            } catch {
                // Stop on first failure — preserves order, retry on next
                // flush opportunity.
                return
            }
        }
    }
}
