import Foundation
import Security
import CryptoKit

/// Storage layer per FR-MOB-03.
///
/// - **Choices** live in UserDefaults. They MUST persist across app restart
///   but MUST NOT survive a reinstall — UserDefaults already gives us this
///   posture (cleared by OS on reinstall / Offload App).
/// - **Session id** lives in Keychain. Keychain items are NOT cleared on
///   reinstall by default, so `loadOrCreateSessionId()` explicitly wipes any
///   stale entry if no UserDefaults choice record exists for that bundle —
///   that's how we force a fresh consent flow after reinstall.
///
/// The `keyPrefix` on init lets tests run in parallel against a per-test
/// namespace without contaminating each other.
final class Persistence {

    private let defaults: UserDefaults
    private let keyPrefix: String
    private let keychainAccount: String

    init(defaults: UserDefaults = .standard, keyPrefix: String = "io.sammati.sdk") {
        self.defaults = defaults
        self.keyPrefix = keyPrefix
        self.keychainAccount = "\(keyPrefix).session"
    }

    // ── Choices (UserDefaults — cleared on reinstall) ─────────────────────

    /// Stored as a JSON-encoded `[String: Bool]` blob keyed by purpose code.
    /// We don't bother with a Codable wrapper struct — the shape is trivial
    /// and a future field addition would be a backwards-compatible JSON
    /// merge, not a struct migration.
    func storeChoices(_ choices: [String: Bool], noticeVersion: String) {
        let envelope: [String: Any] = [
            "notice_version": noticeVersion,
            "choices": choices,
        ]
        if let data = try? JSONSerialization.data(withJSONObject: envelope) {
            defaults.set(data, forKey: choicesKey)
        }
    }

    /// Returns nil if no choices have ever been saved on this install. A
    /// returned envelope MAY have a stale `noticeVersion` — the caller
    /// compares it against the published version to decide whether to
    /// trigger re-consent (FR-MOB-05).
    func loadChoices() -> (choices: [String: Bool], noticeVersion: String)? {
        guard
            let data = defaults.data(forKey: choicesKey),
            let parsed = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
            let noticeVersion = parsed["notice_version"] as? String,
            let choices = parsed["choices"] as? [String: Bool]
        else { return nil }
        return (choices, noticeVersion)
    }

    func clearChoices() {
        defaults.removeObject(forKey: choicesKey)
    }

    private var choicesKey: String { "\(keyPrefix).choices" }

    // ── Per-form consent state (local-first cache for formConsentState) ─────
    //
    // Records "this principal consented to this form at notice version V" so a
    // returning user on an unchanged notice never triggers the per-principal
    // status call. The identifier is SHA-256'd into the key — the raw
    // email/phone is never written to UserDefaults.

    func storeFormState(formKey: String, principalId: String, noticeVersion: Int) {
        defaults.set(noticeVersion, forKey: formStateKey(formKey, principalId))
    }

    /// The notice version the principal last consented to for `formKey`, or nil.
    func loadFormStateNoticeVersion(formKey: String, principalId: String) -> Int? {
        let key = formStateKey(formKey, principalId)
        guard defaults.object(forKey: key) != nil else { return nil }
        return defaults.integer(forKey: key)
    }

    func clearAllFormState() {
        for key in defaults.dictionaryRepresentation().keys where key.hasPrefix(formStatePrefix) {
            defaults.removeObject(forKey: key)
        }
    }

    private var formStatePrefix: String { "\(keyPrefix).formstate." }

    private func formStateKey(_ formKey: String, _ principalId: String) -> String {
        "\(formStatePrefix)\(formKey).\(Self.sha256Hex(principalId))"
    }

    private static func sha256Hex(_ value: String) -> String {
        SHA256.hash(data: Data(value.utf8)).map { String(format: "%02x", $0) }.joined()
    }

    // ── Session id (Keychain — explicitly wiped on first-launch-after-install)

    /// Returns the current session id, creating one if none exists. Honours
    /// the "wipe Keychain if UserDefaults has no record" rule from
    /// FR-MOB-03 to force re-consent after reinstall.
    func loadOrCreateSessionId() -> String {
        if loadChoices() == nil {
            // First launch after install (or after a Clear-Data). Drop any
            // stale Keychain session so the next consent write doesn't
            // re-use a session id from a prior install.
            _ = keychainDelete()
        }
        if let existing = keychainLoad() { return existing }
        let fresh = UUID().uuidString
        _ = keychainStore(fresh)
        return fresh
    }

    func clearSessionId() {
        _ = keychainDelete()
    }

    // ── Keychain primitives ───────────────────────────────────────────────

    private func keychainStore(_ value: String) -> Bool {
        let data = Data(value.utf8)
        let query: [String: Any] = [
            kSecClass as String:       kSecClassGenericPassword,
            kSecAttrAccount as String: keychainAccount,
        ]
        let attributes: [String: Any] = [kSecValueData as String: data]

        // Try update first (cheaper if the item already exists); fall back
        // to add. SecItemAdd with an existing item returns errSecDuplicateItem,
        // not an overwrite — so the explicit update is required.
        let updateStatus = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if updateStatus == errSecSuccess { return true }
        if updateStatus != errSecItemNotFound { return false }

        var addQuery = query
        addQuery[kSecValueData as String] = data
        addQuery[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        return SecItemAdd(addQuery as CFDictionary, nil) == errSecSuccess
    }

    private func keychainLoad() -> String? {
        let query: [String: Any] = [
            kSecClass as String:       kSecClassGenericPassword,
            kSecAttrAccount as String: keychainAccount,
            kSecReturnData as String:  kCFBooleanTrue as Any,
            kSecMatchLimit as String:  kSecMatchLimitOne,
        ]
        var item: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess,
              let data = item as? Data,
              let value = String(data: data, encoding: .utf8)
        else { return nil }
        return value
    }

    private func keychainDelete() -> Bool {
        let query: [String: Any] = [
            kSecClass as String:       kSecClassGenericPassword,
            kSecAttrAccount as String: keychainAccount,
        ]
        let status = SecItemDelete(query as CFDictionary)
        return status == errSecSuccess || status == errSecItemNotFound
    }
}
