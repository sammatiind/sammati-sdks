# Sammati iOS SDK

DPDP-compliant consent banner + preference centre for iOS apps. Drop-in,
zero dependencies, no API key on device. Mirrors the browser
[banner-sdk](../banner-sdk) — your customer-facing app only ever hits the
public `api.sammati.io` routes.

- **iOS 14+**, Swift 5.7+
- **No external dependencies** — URLSession + Keychain + UserDefaults + CryptoKit
- **No API key on device** — security model is bundle-id allowlist + route rate-limiting + optional App Attest (FR-MOB-10)
- **Native UI** (UIKit + SwiftUI) — no WebView per FR-MOB-01
- **Offline-tolerant** — choices buffered to a 10-deep queue and replayed
  on the next online opportunity with a stable Idempotency-Key (FR-MOB-08)
- **22-language coverage** sourced from the tenant's published notice

## Install

### Swift Package Manager (recommended)

```swift
dependencies: [
    .package(url: "https://github.com/sammati-io/sammati-ios", from: "0.1.0"),
],
```

Then add `Sammati` to your target's dependencies.

### CocoaPods

```ruby
pod 'Sammati', '~> 0.1'
```

## Quickstart

```swift
import Sammati
import UIKit

// 1. Configure once at app launch.
@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        Sammati.configure(tenantId: "your-tenant-id")
        return true
    }
}

// 2. Present the banner on first launch (or after withdraw / notice bump).
class HomeViewController: UIViewController {
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        Sammati.showBannerIfNeeded(from: self)
    }
}

// 3. Wire a "Privacy settings" entry in your in-app settings screen.
@IBAction func openPrivacySettings(_ sender: Any) {
    Sammati.openPreferenceCenter(from: self)
}
```

## Public API

| API | What it does |
|---|---|
| `Sammati.configure(tenantId:baseURL:)` | One-time setup. `baseURL` defaults to `https://api.sammati.io`. |
| `Sammati.showBannerIfNeeded(from:completion:)` | Renders the banner if no consent recorded for the current notice version. |
| `Sammati.openPreferenceCenter(from:returnUrl:)` | Opens the hosted preference centre in `SFSafariViewController`. |
| `Sammati.setLocale(_:)` | Explicit locale override (`"hi"`, `"ta"`, etc). Pass `nil` to revert to OS-language resolution. |
| `Sammati.getChoices()` | Returns the stored `[purposeCode: Bool]` map, or `nil` if no consent yet. |
| `Sammati.withdraw()` | Wipes stored choices so the banner re-renders on next call to `showBannerIfNeeded`. |
| `Sammati.reset()` | Hard reset — wipes choices, session id, and offline queue. For QA only. |
| `Sammati.flushOfflineQueue()` | `async` drain of buffered consent writes. Call on `applicationDidBecomeActive` and on reachability flips. |
| `Sammati.queueDepth` | Diagnostic — current depth of the offline queue. |

## Locale resolution (FR-MOB-02)

The SDK walks candidates in this order:

1. Explicit override passed to `Sammati.setLocale(...)`
2. `Locale.preferredLanguages` (OS preference list)
3. The tenant's `language_fallback_chain` from `mobile-config`

Each candidate is reduced to its primary subtag (`bn-Beng-IN` → `bn`) and
matched against the published `label_i18n` keys.

**If no candidate is available** the SDK does **not** silently render
English — `showBannerIfNeeded` is a no-op and the host app decides whether
to block the user or proceed. This is mandated by DPDP §6 (informed
consent in the user's language).

## Persistence (FR-MOB-03)

| What | Where | Survives app restart? | Survives reinstall? |
|---|---|---|---|
| Session id (UUID) | Keychain | ✓ | ✗ (explicitly wiped if UserDefaults envelope is missing) |
| Choices `{purpose → bool}` | UserDefaults | ✓ | ✗ (OS clears on reinstall / Offload App) |

The asymmetry — Keychain survives reinstall, UserDefaults doesn't — is
intentional: detecting "fresh install" lets the SDK force a re-consent
flow per FR-MOB-03 / FR-MOB-05.

## Offline / replay (FR-MOB-08)

Consent writes that fail with transport-level errors are buffered to a
UserDefaults-backed queue with a 10-entry ceiling. Each entry carries a
stable Idempotency-Key — `SHA256(sessionId | noticeVersion | sortedChoices)`
— so a replay collapses into a single server-side artifact.

When the queue hits its ceiling the SDK surfaces `SammatiError.queueOverflow`
rather than silently rotating out older entries — the host app decides
whether to surface "your last choice may not have been recorded".

## Testing

```sh
swift test
```

(Requires full Xcode for the XCTest module. Command Line Tools alone are
not enough — they ship Swift but not XCTest.)

## What's NOT in scope

- App-SDK scanning (deferred to Phase 3)
- Cross-app consent sync (backlog)
- watchOS / tvOS / macCatalyst surfaces (backlog)

See [PRD M10 — Mobile SDK](../../documentation/prd/m10-mobile-sdk.md) for
the canonical scope.
