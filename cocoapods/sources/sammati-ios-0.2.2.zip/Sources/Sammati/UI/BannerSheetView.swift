import Foundation
// Banner is iOS-only. The macOS test build compiles only the
// cross-platform internals; this whole file is excluded there so we
// don't have to chase macOS-version availability for SwiftUI styles
// like `.borderedProminent` that aren't load-bearing on the iOS path.
#if canImport(UIKit) && canImport(SwiftUI)
import SwiftUI

/// SwiftUI banner sheet used by `Sammati.showBannerIfNeeded()`.
///
/// Stateless renderer — all copy comes from the resolved-locale `label_i18n`
/// / `description_i18n` maps on the `MobileConfig`. The host app supplies an
/// `onDecide` callback that's invoked once with the final `[purposeCode: Bool]`
/// choice map plus the user's interaction type. Per FR-MOB-01 we render
/// natively (no WebView) and per FR-MOB-07 we never silently fall back to
/// English when the resolved locale isn't published.
@available(iOS 14.0, *)
struct BannerSheetView: View {

    let config: MobileConfig
    let locale: String
    let onDecide: (ConsentWriteBody.InteractionType, [String: Bool]) -> Void

    @State private var choices: [String: Bool] = [:]
    @State private var showingDetails: Bool = false

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(headerLabel)
                .font(.title3)
                .bold()

            if showingDetails {
                ScrollView {
                    VStack(alignment: .leading, spacing: 12) {
                        ForEach(config.purposes, id: \.purposeId) { purpose in
                            purposeRow(purpose)
                        }
                    }
                }
            } else {
                Text(bodyLabel)
                    .font(.body)
                    .fixedSize(horizontal: false, vertical: true)
            }

            HStack(spacing: 12) {
                Button(action: { onDecide(.rejectAll, allChoices(setTo: false)) }) {
                    Text(localized("reject_all", default: "Reject all"))
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)

                if showingDetails {
                    Button(action: { onDecide(.savePreferences, choices) }) {
                        Text(localized("save_preferences", default: "Save preferences"))
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                } else {
                    Button(action: { onDecide(.acceptAll, allChoices(setTo: true)) }) {
                        Text(localized("accept_all", default: "Accept all"))
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                }
            }

            Button(action: { showingDetails.toggle() }) {
                Text(showingDetails
                     ? localized("hide_details", default: "Hide details")
                     : localized("manage_preferences", default: "Manage preferences"))
                    .font(.footnote)
            }

            if let officer = config.grievanceOfficer.emailMasked {
                Text("\(localized("grievance_officer", default: "Grievance officer")): \(officer)")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
        }
        .padding(20)
        .onAppear { seedChoicesFromDefaults() }
    }

    // ── Per-purpose row ───────────────────────────────────────────────────

    @ViewBuilder
    private func purposeRow(_ purpose: MobileConfig.Purpose) -> some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 4) {
                Text(purpose.labelI18n[locale] ?? purpose.code)
                    .font(.subheadline)
                    .bold()
                if let desc = purpose.descriptionI18n[locale], !desc.isEmpty {
                    Text(desc)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            Spacer()
            // Non-consent bases are disclosure-only: render the toggle as
            // ON and disabled so the user understands they cannot opt out
            // of, say, a legal_obligation purpose.
            Toggle("", isOn: binding(for: purpose))
                .labelsHidden()
                .disabled(purpose.basis != .consent)
        }
    }

    private func binding(for purpose: MobileConfig.Purpose) -> Binding<Bool> {
        Binding(
            get: { choices[purpose.code] ?? purpose.defaultState },
            set: { choices[purpose.code] = $0 }
        )
    }

    private func seedChoicesFromDefaults() {
        guard choices.isEmpty else { return }
        var seeded: [String: Bool] = [:]
        for p in config.purposes { seeded[p.code] = p.defaultState }
        choices = seeded
    }

    private func allChoices(setTo value: Bool) -> [String: Bool] {
        var out: [String: Bool] = [:]
        for p in config.purposes {
            // Non-consent bases are always true regardless of accept/reject.
            out[p.code] = (p.basis == .consent) ? value : true
        }
        return out
    }

    // ── Localised label helpers ───────────────────────────────────────────

    /// Pulls a banner-chrome label out of `label_i18n` for synthetic keys
    /// like `banner.title`, `banner.body`, `banner.accept_all`. The server
    /// publishes these under the same map as purpose labels — see
    /// `documentation/prd/m10-mobile-sdk.md` §FR-MOB-07.
    private func localized(_ key: String, default fallback: String) -> String {
        // The chrome keys are conventionally namespaced as "banner.<key>".
        if let merged = config.purposes.first(where: { $0.code == "__chrome__" })?
            .labelI18n["banner.\(key).\(locale)"] {
            return merged
        }
        return fallback
    }

    private var headerLabel: String {
        localized("title", default: "We value your privacy")
    }

    private var bodyLabel: String {
        // DPDP notice copy: mobile apps don't set cookies. The header
        // explains processing *purposes* (not cookies); each listed purpose
        // is a lawful basis under DPDPA §6.
        localized("body", default: "We process your personal data for the purposes below. Some are essential to deliver the app; you can choose whether to allow the others.")
    }
}
#endif
