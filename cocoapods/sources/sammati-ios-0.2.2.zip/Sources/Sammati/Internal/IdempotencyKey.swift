import Foundation
import CryptoKit

/// Builds a stable Idempotency-Key per FR-MOB-04 so a retry from the offline
/// queue is collapsed to the same artifact server-side. The hash inputs are
/// the same data the consent endpoint already keys on (session, notice,
/// choices), so two different choices in the same session ARE allowed to
/// land distinct artifacts.
enum IdempotencyKey {
    /// Returns a lowercase hex SHA-256 of `sessionId | noticeVersion |
    /// canonical(choices)`. The choice map is canonicalised by sorting keys
    /// before serialisation — two equivalent maps with different insertion
    /// order MUST produce the same key.
    static func derive(sessionId: String, noticeVersion: String, choices: [String: Bool]) -> String {
        let sortedChoices = choices.keys.sorted().map { "\($0)=\(choices[$0] == true ? "1" : "0")" }.joined(separator: ",")
        let payload = "\(sessionId)|\(noticeVersion)|\(sortedChoices)"
        let digest = SHA256.hash(data: Data(payload.utf8))
        return digest.map { String(format: "%02x", $0) }.joined()
    }
}
