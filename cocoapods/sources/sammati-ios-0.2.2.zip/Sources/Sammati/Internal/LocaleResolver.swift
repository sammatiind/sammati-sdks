import Foundation

/// Resolves which locale code the banner should render in, given the user's
/// OS preferences, the tenant's published fallback chain, and any explicit
/// `Sammati.setLocale(...)` override. Implements the order specified in
/// FR-MOB-02.
///
/// Pure functions — no I/O, no global state — so the unit tests can drive
/// the full resolution matrix with fixture inputs.
enum LocaleResolver {

    /// Returns the BEST locale code that is both in `candidates` AND in
    /// `availableLocales`, walking the candidate list in priority order.
    /// Returns nil if no candidate is published. The caller decides what
    /// to do (FR-MOB-02 says: emit `locale_unavailable` telemetry, surface
    /// to the customer app, do NOT silently fall through to English).
    static func resolve(
        explicitOverride: String?,
        osPreferredLanguages: [String],
        fallbackChain: [String],
        availableLocales: Set<String>
    ) -> String? {
        let candidates = orderedCandidates(
            explicitOverride: explicitOverride,
            osPreferredLanguages: osPreferredLanguages,
            fallbackChain: fallbackChain
        )
        for candidate in candidates {
            if let normalized = normalize(candidate), availableLocales.contains(normalized) {
                return normalized
            }
        }
        return nil
    }

    /// Walks the resolution order from FR-MOB-02 and returns every candidate
    /// the resolver will try, in the order it tries them. Exposed for tests.
    static func orderedCandidates(
        explicitOverride: String?,
        osPreferredLanguages: [String],
        fallbackChain: [String]
    ) -> [String] {
        var out: [String] = []
        if let override = explicitOverride { out.append(override) }
        out.append(contentsOf: osPreferredLanguages)
        out.append(contentsOf: fallbackChain)
        return out
    }

    /// Reduces an IETF tag (`hi-IN`, `en_US`, `bn-Beng-IN`) to the primary
    /// language subtag (`hi`, `en`, `bn`). Returns nil for empty input. The
    /// server's `mobile-config` ships `label_i18n` keyed by primary subtag,
    /// so matching at that level is what the protocol expects.
    static func normalize(_ raw: String) -> String? {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }
        let lower = trimmed.lowercased().replacingOccurrences(of: "_", with: "-")
        let primary = lower.split(separator: "-").first.map(String.init) ?? lower
        return primary.isEmpty ? nil : primary
    }
}
