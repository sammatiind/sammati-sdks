import Foundation

/// Closed error set surfaced by the public Sammati API. Mirrors the
/// `error.code` strings used by the core-api `makeApiError` envelope so a
/// caller can correlate device-side failures with server-side audit rows.
///
/// Every public-API call funnels its failures through these — never a bare
/// `URLError` or `DecodingError` — so customer apps can switch on a stable
/// shape and the SDK's surface stays orthogonal to the underlying transport.
public enum SammatiError: Error, Equatable {
    /// Network unavailable, DNS failure, TLS failure, or any transport-layer
    /// problem before the server saw the request. The caller may retry; the
    /// SDK already buffers consent writes via the offline queue.
    case networkUnavailable

    /// The server returned a non-2xx response. `status` is the HTTP code;
    /// `code` is the envelope `error.code` if the body parsed, else nil.
    case httpError(status: Int, code: String?)

    /// The server response did not match the expected schema. This is a
    /// programming error or a deployment skew — surface to the caller so a
    /// crash reporter picks it up, do not silently fall back.
    case decodingFailure(String)

    /// The SDK was used before `Sammati.configure(tenantId:)` was called, or
    /// after `Sammati.reset()` invalidated the configuration.
    case notConfigured

    /// `tenantId` is empty or syntactically malformed (must be non-empty,
    /// max 64 chars, URL-safe).
    case invalidTenantId

    /// Resolved display locale is not in the published notice's translation
    /// set. Per FR-MOB-02 the SDK MUST NOT silently render English in this
    /// case — the customer app decides whether to block the user or proceed.
    case localeUnavailable(resolved: [String])

    /// The offline queue has exceeded its 10-artifact ceiling (FR-MOB-08).
    /// The customer app should surface a "could not save your choice" UI.
    case queueOverflow

    /// Bundle ID is not in the tenant's allowlist (FR-MOB-10). Returned by
    /// the consent endpoint when the server-side gate trips.
    case bundleIdNotAllowed
}

extension SammatiError {
    /// Stable string code for telemetry / cross-platform log correlation.
    public var code: String {
        switch self {
        case .networkUnavailable:        return "network_unavailable"
        case .httpError(_, let code):    return code ?? "http_error"
        case .decodingFailure:           return "decoding_failure"
        case .notConfigured:             return "not_configured"
        case .invalidTenantId:           return "invalid_tenant_id"
        case .localeUnavailable:         return "locale_unavailable"
        case .queueOverflow:             return "queue_overflow"
        case .bundleIdNotAllowed:        return "bundle_id_not_allowed"
        }
    }
}
