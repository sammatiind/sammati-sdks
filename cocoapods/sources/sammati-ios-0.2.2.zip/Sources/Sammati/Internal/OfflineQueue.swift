import Foundation

/// Offline queue for consent writes per FR-MOB-08.
///
/// The SDK MUST surface that the user's choice was captured even when the
/// network is offline — we cannot block the UI on a transport that may not
/// recover. Choices are persisted to a UserDefaults-backed JSON array and
/// drained on the next online opportunity. Idempotency-Key on each entry
/// means a same-payload replay is collapsed server-side, so two flushes
/// after a flaky network can't create duplicate artifacts.
///
/// Ceiling: 10 queued entries. Hitting the ceiling raises `.queueOverflow`
/// rather than silently dropping — the host app decides whether to surface
/// a "your last choice may not have been recorded" banner.
final class OfflineQueue {

    /// One queued consent write. Mirrors `RestClient.postConsent` arguments
    /// so the flush path is a thin loop with no per-entry shape logic.
    struct Entry: Codable, Equatable {
        let tenantId: String
        let body: ConsentWriteBody
        let idempotencyKey: String
        let enqueuedAt: Date
    }

    static let maxDepth = 10

    private let defaults: UserDefaults
    private let storageKey: String

    init(defaults: UserDefaults = .standard, keyPrefix: String = "io.sammati.sdk") {
        self.defaults = defaults
        self.storageKey = "\(keyPrefix).offline_queue"
    }

    func enqueue(_ entry: Entry) throws {
        var entries = load()
        guard entries.count < Self.maxDepth else {
            throw SammatiError.queueOverflow
        }
        entries.append(entry)
        persist(entries)
    }

    func peekAll() -> [Entry] {
        return load()
    }

    /// Removes the entry with the matching idempotency key. We key on the
    /// idempotency key rather than position because the flush loop may
    /// retry out of order (e.g. first entry's 5xx, second entry's 200) and
    /// we don't want a successful drain to delete the wrong row.
    func remove(idempotencyKey: String) {
        let entries = load().filter { $0.idempotencyKey != idempotencyKey }
        persist(entries)
    }

    func clear() {
        defaults.removeObject(forKey: storageKey)
    }

    var depth: Int { load().count }

    // ── Internals ─────────────────────────────────────────────────────────

    private func load() -> [Entry] {
        guard let data = defaults.data(forKey: storageKey) else { return [] }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return (try? decoder.decode([Entry].self, from: data)) ?? []
    }

    private func persist(_ entries: [Entry]) {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        if let data = try? encoder.encode(entries) {
            defaults.set(data, forKey: storageKey)
        }
    }
}
