import Foundation

/// Thin protocol over URLSession so tests can drop in a mock without us
/// having to vend a partial URLSession subclass.
public protocol HttpSession {
    func data(for request: URLRequest) async throws -> (Data, URLResponse)
}

extension URLSession: HttpSession {}

/// REST client for the two endpoints the iOS SDK hits.
///
/// - `GET  /v1/mobile-config/:tenantId`         — fetch published config
/// - `POST /v1/banner/public/:tenantId/consent` — record a consent choice
/// - `POST /v1/banner/public/:tenantId/impression` — record telemetry
///
/// No API key (FR-MOB-04). `tenantId` is the only piece of tenant identity
/// in the URL; the security model is route rate-limiting + bundle-ID
/// allowlist + (optional) attestation.
public final class RestClient {

    /// Sentinel — overridable for staging / dev. The default is the public
    /// production CDN that fronts core-api.
    public static let defaultBaseURL = URL(string: "https://api.sammati.io")!

    private let baseURL: URL
    private let session: HttpSession
    private let decoder: JSONDecoder
    private let encoder: JSONEncoder

    init(baseURL: URL = RestClient.defaultBaseURL, session: HttpSession = URLSession.shared) {
        self.baseURL = baseURL
        self.session = session

        let decoder = JSONDecoder()
        // keyDecodingStrategy stays .useDefaultKeys because every Decodable
        // declares its own snake_case CodingKeys — uniformly applying
        // .convertFromSnakeCase would silently mis-key `purpose_id` -> `purposeId`
        // only if we hadn't already; this way one rule per type, no surprises.
        self.decoder = decoder

        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        self.encoder = encoder
    }

    // ── Mobile config ─────────────────────────────────────────────────────

    func fetchMobileConfig(tenantId: String) async throws -> MobileConfig {
        let url = baseURL.appendingPathComponent("/v1/mobile-config/\(tenantId)")
        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, response) = try await perform(req)
        try ensureSuccess(response: response, data: data)
        do {
            return try decoder.decode(MobileConfig.self, from: data)
        } catch {
            throw SammatiError.decodingFailure(String(describing: error))
        }
    }

    // ── Consent write ─────────────────────────────────────────────────────

    func postConsent(tenantId: String, body: ConsentWriteBody, idempotencyKey: String) async throws {
        let url = baseURL.appendingPathComponent("/v1/banner/public/\(tenantId)/consent")
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        req.setValue(idempotencyKey, forHTTPHeaderField: "Idempotency-Key")
        req.httpBody = try encoder.encode(body)
        let (data, response) = try await perform(req)
        try ensureSuccess(response: response, data: data)
    }

    // ── Form consent (server-driven per-form consent) ─────────────────────

    func postFormConsent(tenantId: String, body: FormConsentBody) async throws {
        let url = baseURL.appendingPathComponent("/v1/banner/public/\(tenantId)/form-consent")
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        req.httpBody = try encoder.encode(body)
        let (data, response) = try await perform(req)
        try ensureSuccess(response: response, data: data)
    }

    func postDiscoverForm(tenantId: String, body: DiscoverFormBody) async throws {
        let url = baseURL.appendingPathComponent("/v1/banner/public/\(tenantId)/discover-form")
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        req.httpBody = try encoder.encode(body)
        let (data, response) = try await perform(req)
        try ensureSuccess(response: response, data: data)
    }

    // ── Impression / telemetry ────────────────────────────────────────────

    func postImpression(tenantId: String, body: ImpressionBody) async throws {
        let url = baseURL.appendingPathComponent("/v1/banner/public/\(tenantId)/impression")
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try encoder.encode(body)
        let (data, response) = try await perform(req)
        try ensureSuccess(response: response, data: data)
    }

    // ── Internals ─────────────────────────────────────────────────────────

    private func perform(_ req: URLRequest) async throws -> (Data, URLResponse) {
        do {
            return try await session.data(for: req)
        } catch is URLError {
            // NSURLErrorDomain failures are transport-level — coalesce into
            // our closed error set so callers don't have to switch on raw
            // POSIX-ish codes.
            throw SammatiError.networkUnavailable
        } catch {
            throw SammatiError.networkUnavailable
        }
    }

    private func ensureSuccess(response: URLResponse, data: Data) throws {
        guard let http = response as? HTTPURLResponse else { throw SammatiError.networkUnavailable }
        guard (200..<300).contains(http.statusCode) else {
            let code = try? Self.extractErrorCode(from: data)
            if http.statusCode == 403, code == "BUNDLE_ID_NOT_ALLOWED" {
                throw SammatiError.bundleIdNotAllowed
            }
            throw SammatiError.httpError(status: http.statusCode, code: code)
        }
    }

    /// Pulls `error.code` out of the standard `makeApiError` envelope:
    /// `{ "error": { "code": "...", "message": "...", "request_id": "..." } }`.
    private static func extractErrorCode(from data: Data) throws -> String? {
        guard
            let parsed = try JSONSerialization.jsonObject(with: data) as? [String: Any],
            let err = parsed["error"] as? [String: Any],
            let code = err["code"] as? String
        else { return nil }
        return code
    }
}

// ── Wire shapes (Encodable — mirror Zod schemas server-side) ──────────────

struct ConsentWriteBody: Codable, Equatable {
    let sessionId: String
    let bannerVersion: String
    let language: String
    let interactionType: InteractionType
    let choices: [String: Bool]
    let collectionMethod: String       // hard-coded "mobile_app"
    let appBundleId: String
    let appVersion: String
    let os: String                     // "ios"
    let osVersion: String
    let deviceModel: String
    let delayedWrite: Bool?            // FR-MOB-08 — true on offline replay

    enum InteractionType: String, Codable {
        case acceptAll = "accept_all"
        case rejectAll = "reject_all"
        case savePreferences = "save_preferences"
    }

    enum CodingKeys: String, CodingKey {
        case sessionId = "session_id"
        case bannerVersion = "banner_version"
        case language
        case interactionType = "interaction_type"
        case choices
        case collectionMethod = "collection_method"
        case appBundleId = "app_bundle_id"
        case appVersion = "app_version"
        case os
        case osVersion = "os_version"
        case deviceModel = "device_model"
        case delayedWrite = "delayed_write"
    }
}

struct FormConsentBody: Encodable, Equatable {
    let fingerprint: String
    let purposes: [String]
    let principalId: String?
    let formAction: String?
    let pageUrl: String
    let collectionMethod: String        // "form_submit"
    let affirmativeAction: String?      // "checkbox_submit"
    let noticeId: String?
    let noticeVersion: Int?
    let uiLocale: String?
    let bannerVersion: String?
    let degraded: Bool?

    // Swift's JSONEncoder omits nil Optionals by default, so the server's
    // `.optional()`-not-`.nullable()` fields are simply absent when nil.
    enum CodingKeys: String, CodingKey {
        case fingerprint, purposes
        case principalId = "principal_id"
        case formAction = "form_action"
        case pageUrl = "page_url"
        case collectionMethod = "collection_method"
        case affirmativeAction = "affirmative_action"
        case noticeId = "notice_id"
        case noticeVersion = "notice_version"
        case uiLocale = "ui_locale"
        case bannerVersion = "banner_version"
        case degraded
    }
}

struct DiscoverFormBody: Encodable, Equatable {
    let version: Int                    // literal 1
    let bannerVersion: String?
    let fingerprint: String
    let selector: String
    let action: String?
    let pageUrl: String
    let fields: [Field]

    struct Field: Encodable, Equatable {
        let name: String
        let htmlType: String?
        let placeholder: String?
        let label: String?
        let required: Bool
        let autocomplete: String?

        enum CodingKeys: String, CodingKey {
            case name
            case htmlType = "html_type"
            case placeholder, label, required, autocomplete
        }
    }

    enum CodingKeys: String, CodingKey {
        case version
        case bannerVersion = "banner_version"
        case fingerprint, selector, action
        case pageUrl = "page_url"
        case fields
    }
}

struct ImpressionBody: Encodable, Equatable {
    let sessionId: String
    let bannerShown: Bool
    let bannerVersion: String?
    let language: String

    enum CodingKeys: String, CodingKey {
        case sessionId = "session_id"
        case bannerShown = "banner_shown"
        case bannerVersion = "banner_version"
        case language
    }
}
