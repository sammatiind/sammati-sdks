import Foundation

/// Wire shape of `GET /v1/mobile-config/:tenantId`. Mirrors the Zod schema
/// at `services/core-api/src/modules/m10-mobile-sdk/mobile-config.schema.ts`.
///
/// `Decodable` only — the SDK never POSTs this shape, so we don't pay for
/// the `Encodable` synthesis.
public struct MobileConfig: Decodable, Equatable {
    public let tenantId: String
    public let noticeVersion: String
    public let publishedAt: String?
    public let languageFallbackChain: [String]
    public let purposes: [Purpose]
    public let grievanceOfficer: GrievanceOfficer
    public let bundleIdAllowlist: [String]
    public let attestationRequired: Bool
    /// Server-driven per-form consent mappings (platform='mobile'). Empty
    /// until the admin maps an app form in the /pii-forms portal.
    public let forms: [FormMapping]

    public struct Purpose: Decodable, Equatable {
        public let purposeId: String
        public let code: String
        public let basis: Basis
        public let labelI18n: [String: String]
        public let descriptionI18n: [String: String]
        public let sensitive: Bool
        public let defaultState: Bool

        public enum Basis: String, Decodable, Equatable {
            case consent
            case legitimateUse = "legitimate_use"
            case contractual
            case legalObligation = "legal_obligation"
        }

        enum CodingKeys: String, CodingKey {
            case purposeId = "purpose_id"
            case code
            case basis
            case labelI18n = "label_i18n"
            case descriptionI18n = "description_i18n"
            case sensitive
            case defaultState = "default_state"
        }
    }

    public struct GrievanceOfficer: Decodable, Equatable {
        public let name: String?
        public let emailMasked: String?
        public let phoneMasked: String?

        enum CodingKeys: String, CodingKey {
            case name
            case emailMasked = "email_masked"
            case phoneMasked = "phone_masked"
        }
    }

    public struct FormMapping: Decodable, Equatable {
        public let formKey: String
        public let uxMode: String
        public let purposes: [FormPurpose]
        public let notice: FormNotice?

        public struct FormPurpose: Decodable, Equatable {
            public let code: String
            public let basis: Purpose.Basis
            public let required: Bool
            public let labelI18n: [String: String]

            enum CodingKeys: String, CodingKey {
                case code, basis, required
                case labelI18n = "label_i18n"
            }
        }

        public struct FormNotice: Decodable, Equatable {
            public let id: String
            public let version: Int
            public let defaultLanguage: String
            public let contents: [Content]

            public struct Content: Decodable, Equatable {
                public let language: String
                public let title: String
                public let body: String
                public let shortDescription: String

                enum CodingKeys: String, CodingKey {
                    case language, title, body
                    case shortDescription = "short_description"
                }
            }

            enum CodingKeys: String, CodingKey {
                case id, version, contents
                case defaultLanguage = "default_language"
            }
        }

        enum CodingKeys: String, CodingKey {
            case formKey = "form_key"
            case uxMode = "ux_mode"
            case purposes, notice
        }
    }

    enum CodingKeys: String, CodingKey {
        case tenantId = "tenant_id"
        case noticeVersion = "notice_version"
        case publishedAt = "published_at"
        case languageFallbackChain = "language_fallback_chain"
        case purposes
        case grievanceOfficer = "grievance_officer"
        case bundleIdAllowlist = "bundle_id_allowlist"
        case attestationRequired = "attestation_required"
        case forms
    }

    // Custom decode so `forms` (and the two MOB-09 fields) default gracefully
    // when an older core-api deployment omits them — the decode never fails on
    // a missing optional-with-default field.
    public init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        tenantId = try c.decode(String.self, forKey: .tenantId)
        noticeVersion = try c.decode(String.self, forKey: .noticeVersion)
        publishedAt = try c.decodeIfPresent(String.self, forKey: .publishedAt)
        languageFallbackChain = try c.decode([String].self, forKey: .languageFallbackChain)
        purposes = try c.decode([Purpose].self, forKey: .purposes)
        grievanceOfficer = try c.decode(GrievanceOfficer.self, forKey: .grievanceOfficer)
        bundleIdAllowlist = try c.decodeIfPresent([String].self, forKey: .bundleIdAllowlist) ?? []
        attestationRequired = try c.decodeIfPresent(Bool.self, forKey: .attestationRequired) ?? false
        forms = try c.decodeIfPresent([FormMapping].self, forKey: .forms) ?? []
    }
}
