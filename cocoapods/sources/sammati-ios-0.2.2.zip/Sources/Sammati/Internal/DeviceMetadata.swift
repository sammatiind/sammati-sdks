import Foundation
#if canImport(UIKit)
import UIKit
#endif

/// Device-side metadata included on every consent / impression POST per
/// FR-MOB-04. Never includes IMEI, MAC, advertising id, or anything that
/// can re-identify a device across reinstalls.
struct DeviceMetadata {
    let appBundleId: String
    let appVersion: String
    let os: String
    let osVersion: String
    let deviceModel: String

    static func current(bundle: Bundle = .main) -> DeviceMetadata {
        let bundleId = bundle.bundleIdentifier ?? ""
        let version = (bundle.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String) ?? ""
        return DeviceMetadata(
            appBundleId: bundleId,
            appVersion: version,
            os: "ios",
            osVersion: Self.osVersion(),
            deviceModel: Self.deviceModel()
        )
    }

    private static func osVersion() -> String {
        #if canImport(UIKit)
        return UIDevice.current.systemVersion
        #else
        return ProcessInfo.processInfo.operatingSystemVersionString
        #endif
    }

    /// Returns the hardware model identifier (e.g. `iPhone14,3`). Reading
    /// the `hw.machine` sysctl is the standard pattern; `UIDevice.model`
    /// only returns "iPhone" / "iPad" which is too coarse for the audit row.
    private static func deviceModel() -> String {
        var size: size_t = 0
        sysctlbyname("hw.machine", nil, &size, nil, 0)
        guard size > 0 else { return "unknown" }
        var raw = [CChar](repeating: 0, count: Int(size))
        sysctlbyname("hw.machine", &raw, &size, nil, 0)
        return String(cString: raw)
    }
}
