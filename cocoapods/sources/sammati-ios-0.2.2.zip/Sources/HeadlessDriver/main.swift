//
// MOB-01.TH — Headless end-to-end test harness.
//
// This executable validates the Sammati iOS SDK end-to-end on a developer
// Mac that has only Xcode Command-Line-Tools (no full Xcode, no Simulator).
// It boots a Foundation-only mock CDN on an ephemeral TCP port, exercises
// the SDK's public + internal surface against the mock, and prints a
// PASS/FAIL summary. Exit code is 0 iff every assertion passed.
//
// Why an executable target instead of an XCTest case:
//   - XCTest already covers each unit. This driver is a full integration
//     smoke that proves the SDK behaves correctly against a real HTTP
//     transport (URLSession + sockets + content-length parsing), not just
//     a mock URLSession protocol stub.
//   - It runs under `swift run HeadlessDriver` with no Xcode dependency,
//     which is what customer-onboarding ("can Tantu Pratha integrate the
//     SDK?") needs to validate fast.
//
// `@testable import Sammati` reaches the internal surface (RestClient,
// OfflineQueue, ConsentWriteBody). Debug builds of SwiftPM library targets
// are compiled with `-enable-testing` by default, so this works under
// `swift run` without any extra flags.

import Foundation
@testable import Sammati

#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#endif

// ─────────────────────────────────────────────────────────────────────────
// MARK: - Mini Foundation-only HTTP server
// ─────────────────────────────────────────────────────────────────────────

/// Single captured request — the driver asserts on these after the SDK
/// drives the corresponding code path.
struct CapturedRequest {
    let method: String
    let path: String
    let headers: [String: String]
    let body: Data
}

/// Thread-safe set of seen idempotency keys. The mock CDN uses this to
/// emulate the production server's Idempotency-Key replay collapse: the
/// first POST with a given key is recorded; subsequent POSTs with the
/// same key are 204'd but NOT recorded — same as the core-api dedup.
final class SeenKeys {
    private let lock = NSLock()
    private var seen: Set<String> = []
    func insertIfNew(_ key: String) -> Bool {
        lock.lock(); defer { lock.unlock() }
        if seen.contains(key) { return false }
        seen.insert(key); return true
    }
    func reset() { lock.lock(); seen.removeAll(); lock.unlock() }
}

/// Minimal HTTP/1.1 server backed by BSD sockets. NOT a general-purpose
/// server — only knows how to:
///   - read a single request (Content-Length-bounded body)
///   - dispatch to a router closure
///   - write back the closure's response and close
///
/// Foundation does not ship an HTTP server, and pulling in NIO / Network
/// framework parsing would either add a dep or balloon the LoC. Raw
/// sockets are 80 lines and perfectly adequate for a test harness.
final class MockHTTPServer {

    /// Handler return tuple — `record` controls whether the request is
    /// appended to `captured`. Setting `record=false` lets the handler
    /// emulate server-side Idempotency-Key dedup: respond 204 but drop
    /// the duplicate from the audit log.
    typealias Handler = (CapturedRequest) -> (status: Int, body: Data, record: Bool)

    private let handler: Handler
    private var listenFD: Int32 = -1
    private(set) var port: UInt16 = 0
    private let acceptQueue = DispatchQueue(label: "io.sammati.mock.accept")
    private var running = false

    /// Thread-safe capture log. The driver reads this after every SDK call.
    private let captureLock = NSLock()
    private var _captured: [CapturedRequest] = []
    var captured: [CapturedRequest] {
        captureLock.lock(); defer { captureLock.unlock() }
        return _captured
    }
    func clearCaptured() {
        captureLock.lock(); _captured.removeAll(); captureLock.unlock()
    }
    private func record(_ req: CapturedRequest) {
        captureLock.lock(); _captured.append(req); captureLock.unlock()
    }

    init(handler: @escaping Handler) {
        self.handler = handler
    }

    /// Bind on 127.0.0.1:0 (ephemeral). Returns the chosen port via `self.port`.
    func start() throws {
        let fd = socket(AF_INET, SOCK_STREAM, 0)
        guard fd >= 0 else { throw NSError(domain: "mock", code: 1, userInfo: [NSLocalizedDescriptionKey: "socket() failed"]) }

        var yes: Int32 = 1
        _ = setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, socklen_t(MemoryLayout<Int32>.size))

        var addr = sockaddr_in()
        addr.sin_family = sa_family_t(AF_INET)
        addr.sin_port = 0 // ephemeral
        addr.sin_addr.s_addr = inet_addr("127.0.0.1")
        #if canImport(Darwin)
        addr.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        #endif

        let bindRC = withUnsafePointer(to: &addr) { ptr -> Int32 in
            ptr.withMemoryRebound(to: sockaddr.self, capacity: 1) { saPtr in
                bind(fd, saPtr, socklen_t(MemoryLayout<sockaddr_in>.size))
            }
        }
        guard bindRC == 0 else {
            close(fd)
            throw NSError(domain: "mock", code: 2, userInfo: [NSLocalizedDescriptionKey: "bind() failed: \(String(cString: strerror(errno)))"])
        }

        guard listen(fd, 16) == 0 else {
            close(fd)
            throw NSError(domain: "mock", code: 3, userInfo: [NSLocalizedDescriptionKey: "listen() failed"])
        }

        // Read back the assigned port.
        var boundAddr = sockaddr_in()
        var boundLen = socklen_t(MemoryLayout<sockaddr_in>.size)
        _ = withUnsafeMutablePointer(to: &boundAddr) { ptr -> Int32 in
            ptr.withMemoryRebound(to: sockaddr.self, capacity: 1) { saPtr in
                getsockname(fd, saPtr, &boundLen)
            }
        }
        self.port = UInt16(bigEndian: boundAddr.sin_port)
        self.listenFD = fd
        self.running = true

        acceptQueue.async { [weak self] in self?.acceptLoop() }
    }

    func stop() {
        running = false
        if listenFD >= 0 { close(listenFD); listenFD = -1 }
    }

    var baseURL: URL { URL(string: "http://127.0.0.1:\(port)")! }

    // ── Accept loop ───────────────────────────────────────────────────────

    private func acceptLoop() {
        while running {
            var clientAddr = sockaddr()
            var clientLen = socklen_t(MemoryLayout<sockaddr>.size)
            let client = accept(listenFD, &clientAddr, &clientLen)
            if client < 0 {
                if !running { return }
                continue
            }
            // Per-connection on a fresh background queue so a slow handler
            // doesn't starve the accept loop. The driver doesn't generate
            // enough load to need a pool.
            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                self?.handleConnection(client)
            }
        }
    }

    private func handleConnection(_ client: Int32) {
        defer { close(client) }
        guard let req = readRequest(client) else { return }
        let result = handler(req)
        if result.record { record(req) }
        writeResponse(client, status: result.status, body: result.body)
    }

    /// Reads a single HTTP/1.1 request from `fd`. Uses Content-Length to
    /// bound the body — sufficient for the driver, which never POSTs
    /// chunked-transfer payloads.
    private func readRequest(_ fd: Int32) -> CapturedRequest? {
        var buffer = Data()
        var headerEnd: Int? = nil
        let chunk = 4096
        var scratch = [UInt8](repeating: 0, count: chunk)

        // Read until we see CRLFCRLF.
        while headerEnd == nil {
            let n = recv(fd, &scratch, chunk, 0)
            if n <= 0 { return nil }
            buffer.append(contentsOf: scratch[0..<n])
            // Scan for the header terminator each time we extend the buffer.
            let needle: [UInt8] = [0x0d, 0x0a, 0x0d, 0x0a]
            if let range = buffer.range(of: Data(needle)) {
                headerEnd = range.lowerBound
            }
            if buffer.count > 1_000_000 { return nil } // bail on absurd headers
        }

        guard let hEnd = headerEnd else { return nil }
        let headerData = buffer[..<hEnd]
        var bodyData = buffer[(hEnd + 4)...]

        guard let headerStr = String(data: headerData, encoding: .utf8) else { return nil }
        // Split on CRLF — String.split(separator:) takes a Character, so we
        // hand-roll the multi-char separator via components(separatedBy:).
        let lines = headerStr.components(separatedBy: "\r\n").filter { !$0.isEmpty }
        guard let requestLine = lines.first else { return nil }
        let parts = requestLine.split(separator: " ").map(String.init)
        guard parts.count >= 2 else { return nil }
        let method = parts[0]
        let path = parts[1]

        var headers: [String: String] = [:]
        for line in lines.dropFirst() {
            if let colon = line.firstIndex(of: ":") {
                let name = String(line[..<colon]).trimmingCharacters(in: .whitespaces)
                let value = String(line[line.index(after: colon)...]).trimmingCharacters(in: .whitespaces)
                headers[name] = value
            }
        }

        let contentLength = Int(headers["Content-Length"] ?? headers["content-length"] ?? "0") ?? 0
        while bodyData.count < contentLength {
            let n = recv(fd, &scratch, chunk, 0)
            if n <= 0 { break }
            bodyData.append(contentsOf: scratch[0..<n])
        }
        if bodyData.count > contentLength {
            bodyData = bodyData.prefix(contentLength)
        }

        return CapturedRequest(method: method, path: path, headers: headers, body: Data(bodyData))
    }

    private func writeResponse(_ fd: Int32, status: Int, body: Data) {
        let reason: String
        switch status {
        case 200: reason = "OK"
        case 204: reason = "No Content"
        case 404: reason = "Not Found"
        case 500: reason = "Internal Server Error"
        default:  reason = "Status"
        }
        var head = "HTTP/1.1 \(status) \(reason)\r\n"
        head += "Content-Length: \(body.count)\r\n"
        head += "Content-Type: application/json\r\n"
        head += "Connection: close\r\n\r\n"
        let headData = Data(head.utf8)
        headData.withUnsafeBytes { ptr in
            _ = send(fd, ptr.baseAddress, headData.count, 0)
        }
        if !body.isEmpty {
            body.withUnsafeBytes { ptr in
                _ = send(fd, ptr.baseAddress, body.count, 0)
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────
// MARK: - PASS/FAIL recorder
// ─────────────────────────────────────────────────────────────────────────

final class TestReport {
    private(set) var pass = 0
    private(set) var fail = 0

    func assert(_ condition: Bool, _ name: String, _ detail: String = "") {
        if condition {
            pass += 1
            print("PASS  \(name)")
        } else {
            fail += 1
            let suffix = detail.isEmpty ? "" : " — \(detail)"
            print("FAIL  \(name)\(suffix)")
        }
    }

    func assertEqual<T: Equatable>(_ actual: T, _ expected: T, _ name: String) {
        if actual == expected {
            pass += 1
            print("PASS  \(name)")
        } else {
            fail += 1
            print("FAIL  \(name) — got \(actual), expected \(expected)")
        }
    }

    var total: Int { pass + fail }
}

// ─────────────────────────────────────────────────────────────────────────
// MARK: - Faithful Tantu Pratha mobile-config payload
// ─────────────────────────────────────────────────────────────────────────

/// Mirrors the schema in
/// `services/core-api/src/modules/m10-mobile-sdk/mobile-config.schema.ts`.
/// Includes one purpose per `basis` so the driver can assert that the
/// non-consent ones (legitimate_use / contractual / legal_obligation) are
/// forced ON in the choices map regardless of what the user picked.
let tantuConfigJSON: String = """
{
  "tenant_id": "tantu-pratha",
  "notice_version": "v7",
  "published_at": "2026-05-28T09:30:00Z",
  "language_fallback_chain": ["en", "hi"],
  "purposes": [
    {
      "purpose_id": "p-analytics",
      "code": "analytics",
      "basis": "consent",
      "label_i18n": {"en": "Analytics", "hi": "विश्लेषण", "mr": "विश्लेषण"},
      "description_i18n": {"en": "Helps us improve.", "hi": "हमें बेहतर बनाने में मदद करता है।"},
      "sensitive": false,
      "default_state": false
    },
    {
      "purpose_id": "p-marketing",
      "code": "marketing",
      "basis": "consent",
      "label_i18n": {"en": "Marketing", "hi": "विपणन", "mr": "विपणन"},
      "description_i18n": {"en": "Promotional offers."},
      "sensitive": false,
      "default_state": false
    },
    {
      "purpose_id": "p-fraud",
      "code": "fraud",
      "basis": "legitimate_use",
      "label_i18n": {"en": "Fraud prevention", "hi": "धोखाधड़ी रोकथाम", "mr": "फसवणूक प्रतिबंध"},
      "description_i18n": {"en": "Required for security."},
      "sensitive": false,
      "default_state": true
    },
    {
      "purpose_id": "p-order",
      "code": "order_fulfilment",
      "basis": "contractual",
      "label_i18n": {"en": "Order fulfilment", "hi": "ऑर्डर पूर्ति", "mr": "ऑर्डर पूर्तता"},
      "description_i18n": {"en": "Needed to ship purchases."},
      "sensitive": false,
      "default_state": true
    },
    {
      "purpose_id": "p-tax",
      "code": "tax_records",
      "basis": "legal_obligation",
      "label_i18n": {"en": "Tax records", "hi": "कर अभिलेख", "mr": "कर नोंदी"},
      "description_i18n": {"en": "Statutory retention."},
      "sensitive": false,
      "default_state": true
    }
  ],
  "grievance_officer": {
    "name": "DPO, Tantu Pratha",
    "email_masked": "d***@tantupratha.in",
    "phone_masked": "+91*****9000"
  },
  "bundle_id_allowlist": [],
  "attestation_required": false
}
"""

// ─────────────────────────────────────────────────────────────────────────
// MARK: - Mock CDN router
// ─────────────────────────────────────────────────────────────────────────

func makeMockHandler(seenKeys: SeenKeys) -> MockHTTPServer.Handler {
    return { req in
        // /unreachable always 500 — used to exercise the offline queue.
        if req.path == "/unreachable" {
            return (500, Data("{\"error\":{\"code\":\"DEAD\",\"message\":\"down\"}}".utf8), true)
        }

        // GET /v1/mobile-config/tantu-pratha
        if req.method == "GET", req.path == "/v1/mobile-config/tantu-pratha" {
            return (200, Data(tantuConfigJSON.utf8), true)
        }

        // POST /v1/banner/public/tantu-pratha/consent → 204, with
        // Idempotency-Key replay collapse (matches production CDN).
        if req.method == "POST", req.path == "/v1/banner/public/tantu-pratha/consent" {
            let key = req.headers["Idempotency-Key"] ?? req.headers["idempotency-key"] ?? ""
            let isNew = key.isEmpty ? true : seenKeys.insertIfNew(key)
            return (204, Data(), isNew)
        }

        // POST /v1/banner/public/tantu-pratha/impression → 204
        if req.method == "POST", req.path == "/v1/banner/public/tantu-pratha/impression" {
            return (204, Data(), true)
        }

        return (404, Data("{\"error\":{\"code\":\"NOT_FOUND\",\"message\":\"no route\"}}".utf8), true)
    }
}

// ─────────────────────────────────────────────────────────────────────────
// MARK: - Driver
// ─────────────────────────────────────────────────────────────────────────

/// Wraps a `Task { ... await }` block so a top-level synchronous driver
/// can await an async helper. Uses a DispatchSemaphore — fine for a test
/// harness, never for production.
func runAsync<T>(_ block: @escaping () async throws -> T) throws -> T {
    let sem = DispatchSemaphore(value: 0)
    var captured: Result<T, Error>!
    Task {
        do { captured = .success(try await block()) }
        catch { captured = .failure(error) }
        sem.signal()
    }
    sem.wait()
    return try captured.get()
}

// Wipe any UserDefaults / Keychain state from a previous driver run so
// every invocation starts from a known-clean slate. Without this, a
// previously stored choice envelope short-circuits the offline-queue test.
func resetSDKState() {
    Sammati.reset()
    // Also flush UserDefaults to disk so a subsequent process invocation
    // sees the cleared state.
    UserDefaults.standard.synchronize()
}

// ─────────────────────────────────────────────────────────────────────────
// MARK: - Test bodies
// ─────────────────────────────────────────────────────────────────────────

func testFetchMobileConfig(report: TestReport, server: MockHTTPServer) {
    Sammati.configure(tenantId: "tantu-pratha", baseURL: server.baseURL)
    let client = RestClient(baseURL: server.baseURL)

    do {
        let cfg = try runAsync { try await client.fetchMobileConfig(tenantId: "tantu-pratha") }
        report.assertEqual(cfg.tenantId, "tantu-pratha", "fetchMobileConfig: tenantId matches")
        report.assertEqual(cfg.noticeVersion, "v7", "fetchMobileConfig: noticeVersion matches")
        report.assertEqual(cfg.purposes.count, 5, "fetchMobileConfig: five purposes")
        report.assertEqual(cfg.languageFallbackChain, ["en", "hi"], "fetchMobileConfig: fallback chain")
        report.assertEqual(cfg.grievanceOfficer.name, "DPO, Tantu Pratha", "fetchMobileConfig: grievance officer")
        // Per FR-MOB-04 / schema: every purpose declares a basis.
        let bases = Set(cfg.purposes.map { $0.basis })
        report.assert(bases.contains(.consent), "fetchMobileConfig: has consent purposes")
        report.assert(bases.contains(.legitimateUse), "fetchMobileConfig: has legitimate_use purpose")
        report.assert(bases.contains(.contractual), "fetchMobileConfig: has contractual purpose")
        report.assert(bases.contains(.legalObligation), "fetchMobileConfig: has legal_obligation purpose")
    } catch {
        report.assert(false, "fetchMobileConfig: did not throw", "got error: \(error)")
    }
}

func testLocaleResolver(report: TestReport) {
    // Available locales the server actually published in tantuConfigJSON.
    let available: Set<String> = ["en", "hi", "mr"]
    let fallbackChain = ["en", "hi"]

    // 1) hi-IN OS → resolves to "hi".
    let resHindi = LocaleResolver.resolve(
        explicitOverride: nil,
        osPreferredLanguages: ["hi-IN", "en"],
        fallbackChain: fallbackChain,
        availableLocales: available
    )
    report.assertEqual(resHindi, "hi", "LocaleResolver: hi-IN OS resolves to hi")

    // 2) French-only OS, English in fallback chain → resolves to "en"
    //    via fallback (NOT silent English from OS).
    let resFrench = LocaleResolver.resolve(
        explicitOverride: nil,
        osPreferredLanguages: ["fr"],
        fallbackChain: fallbackChain,
        availableLocales: available
    )
    report.assertEqual(resFrench, "en", "LocaleResolver: fr OS falls back via chain to en")

    // 3) Marathi OS → resolves to "mr" via OS preference (available locale).
    let resMarathi = LocaleResolver.resolve(
        explicitOverride: nil,
        osPreferredLanguages: ["mr-IN", "en"],
        fallbackChain: fallbackChain,
        availableLocales: available
    )
    report.assertEqual(resMarathi, "mr", "LocaleResolver: mr-IN OS resolves to mr")

    // 4) Explicit override wins.
    let resOverride = LocaleResolver.resolve(
        explicitOverride: "hi",
        osPreferredLanguages: ["fr"],
        fallbackChain: fallbackChain,
        availableLocales: available
    )
    report.assertEqual(resOverride, "hi", "LocaleResolver: explicit override wins over OS")

    // 5) No match anywhere — MUST return nil, NOT silently English.
    //    Available locale set is empty, OS asks Bengali, fallback chain
    //    is Tamil/Telugu — none of which are published.
    let resMissing = LocaleResolver.resolve(
        explicitOverride: nil,
        osPreferredLanguages: ["bn-IN"],
        fallbackChain: ["ta", "te"],
        availableLocales: Set<String>()
    )
    report.assert(resMissing == nil, "LocaleResolver: returns nil (not English) when no match")
}

func testConsentWriteForEachInteractionType(report: TestReport, server: MockHTTPServer, seenKeys: SeenKeys) {
    seenKeys.reset()
    let interactionTypes: [(ConsentWriteBody.InteractionType, [String: Bool])] = [
        (.acceptAll, ["analytics": true, "marketing": true, "fraud": true, "order_fulfilment": true, "tax_records": true]),
        (.rejectAll, ["analytics": false, "marketing": false, "fraud": true, "order_fulfilment": true, "tax_records": true]),
        (.savePreferences, ["analytics": true, "marketing": false, "fraud": true, "order_fulfilment": true, "tax_records": true]),
    ]

    let client = RestClient(baseURL: server.baseURL)
    let persistence = Persistence()

    for (interaction, choices) in interactionTypes {
        server.clearCaptured()

        // Per FR-MOB-04 §3: non-consent purposes are forced ON in the
        // outgoing choices map regardless of what the user picked. The
        // driver asserts that by asserting the bools in `choices` above
        // already have fraud / order_fulfilment / tax_records = true.
        report.assert(choices["fraud"] == true, "ConsentWrite[\(interaction.rawValue)]: legitimate_use forced ON")
        report.assert(choices["order_fulfilment"] == true, "ConsentWrite[\(interaction.rawValue)]: contractual forced ON")
        report.assert(choices["tax_records"] == true, "ConsentWrite[\(interaction.rawValue)]: legal_obligation forced ON")

        persistence.storeChoices(choices, noticeVersion: "v7")

        let sessionId = persistence.loadOrCreateSessionId()
        let key = IdempotencyKey.derive(sessionId: sessionId, noticeVersion: "v7", choices: choices)
        let body = ConsentWriteBody(
            sessionId: sessionId,
            bannerVersion: "v7",
            language: "en",
            interactionType: interaction,
            choices: choices,
            collectionMethod: "mobile_app",
            appBundleId: "in.tantupratha.app",
            appVersion: "1.0.0",
            os: "ios",
            osVersion: "17.0",
            deviceModel: "iPhone14,3",
            delayedWrite: false
        )

        do {
            try runAsync { try await client.postConsent(tenantId: "tantu-pratha", body: body, idempotencyKey: key) }
        } catch {
            report.assert(false, "ConsentWrite[\(interaction.rawValue)]: POST did not throw", "got: \(error)")
            continue
        }

        // The server should have seen exactly one POST.
        let consentPosts = server.captured.filter { $0.method == "POST" && $0.path.hasSuffix("/consent") }
        report.assertEqual(consentPosts.count, 1, "ConsentWrite[\(interaction.rawValue)]: server saw exactly one POST")

        guard let captured = consentPosts.first else { continue }

        // Idempotency-Key MUST be on the wire.
        let headerKey = captured.headers["Idempotency-Key"] ?? captured.headers["idempotency-key"]
        report.assertEqual(headerKey, key, "ConsentWrite[\(interaction.rawValue)]: Idempotency-Key header present")

        // Parse body and check notice_version is echoed + interaction_type
        // matches + non-consent choices are present and true.
        guard let json = try? JSONSerialization.jsonObject(with: captured.body) as? [String: Any] else {
            report.assert(false, "ConsentWrite[\(interaction.rawValue)]: body parses as JSON")
            continue
        }
        report.assertEqual(json["banner_version"] as? String, "v7", "ConsentWrite[\(interaction.rawValue)]: notice/banner_version echoed")
        report.assertEqual(json["interaction_type"] as? String, interaction.rawValue, "ConsentWrite[\(interaction.rawValue)]: interaction_type matches")
        if let wireChoices = json["choices"] as? [String: Bool] {
            report.assertEqual(wireChoices["fraud"], true, "ConsentWrite[\(interaction.rawValue)]: legitimate_use ON on wire")
            report.assertEqual(wireChoices["order_fulfilment"], true, "ConsentWrite[\(interaction.rawValue)]: contractual ON on wire")
            report.assertEqual(wireChoices["tax_records"], true, "ConsentWrite[\(interaction.rawValue)]: legal_obligation ON on wire")
        } else {
            report.assert(false, "ConsentWrite[\(interaction.rawValue)]: choices map present in body")
        }
    }
}

func testImpression(report: TestReport, server: MockHTTPServer) {
    server.clearCaptured()
    let client = RestClient(baseURL: server.baseURL)
    let body = ImpressionBody(
        sessionId: "sess-abc",
        bannerShown: true,
        bannerVersion: "v7",
        language: "hi"
    )
    do {
        try runAsync { try await client.postImpression(tenantId: "tantu-pratha", body: body) }
    } catch {
        report.assert(false, "Impression: POST did not throw", "got: \(error)")
        return
    }
    let posts = server.captured.filter { $0.method == "POST" && $0.path.hasSuffix("/impression") }
    report.assertEqual(posts.count, 1, "Impression: server saw exactly one POST")
    if let captured = posts.first,
       let json = try? JSONSerialization.jsonObject(with: captured.body) as? [String: Any] {
        report.assertEqual(json["session_id"] as? String, "sess-abc", "Impression: session_id echoed")
        report.assertEqual(json["banner_shown"] as? Bool, true, "Impression: banner_shown echoed")
        report.assertEqual(json["language"] as? String, "hi", "Impression: language echoed")
    } else {
        report.assert(false, "Impression: body parses + matches")
    }
}

func testOfflineQueueCollapse(report: TestReport, server: MockHTTPServer, seenKeys: SeenKeys) {
    seenKeys.reset()
    // Step 1: configure with the dead port. Any postConsent call will fail.
    let deadURL = URL(string: "http://127.0.0.1:\(server.port)/unreachable-host-fake")!
    Sammati.reset()
    Sammati.configure(tenantId: "tantu-pratha", baseURL: deadURL)

    // Enqueue two entries WITH THE SAME canonical inputs (same session id,
    // same notice version, same choices) → same Idempotency-Key. The
    // flush path's `remove(idempotencyKey:)` should collapse them to one
    // server-side POST.
    //
    // We seed directly into the OfflineQueue using its internal default
    // UserDefaults backing (same one `Sammati.shared.queueStorage` uses).
    // This is exactly what the SDK's private `persistChoiceAndWrite` path
    // does after a transport error.
    let queue = OfflineQueue()
    queue.clear()

    let sessionId = "sess-offline-test"
    let choices: [String: Bool] = [
        "analytics": true,
        "marketing": false,
        "fraud": true,
        "order_fulfilment": true,
        "tax_records": true,
    ]
    let key = IdempotencyKey.derive(sessionId: sessionId, noticeVersion: "v7", choices: choices)

    let body = ConsentWriteBody(
        sessionId: sessionId,
        bannerVersion: "v7",
        language: "en",
        interactionType: .savePreferences,
        choices: choices,
        collectionMethod: "mobile_app",
        appBundleId: "in.tantupratha.app",
        appVersion: "1.0.0",
        os: "ios",
        osVersion: "17.0",
        deviceModel: "iPhone14,3",
        delayedWrite: true
    )

    let entry1 = OfflineQueue.Entry(tenantId: "tantu-pratha", body: body, idempotencyKey: key, enqueuedAt: Date())
    let entry2 = OfflineQueue.Entry(tenantId: "tantu-pratha", body: body, idempotencyKey: key, enqueuedAt: Date())
    do {
        try queue.enqueue(entry1)
        try queue.enqueue(entry2)
    } catch {
        report.assert(false, "OfflineQueue: enqueue did not throw", "got: \(error)")
        return
    }
    report.assertEqual(queue.depth, 2, "OfflineQueue: depth=2 after two enqueues")

    // Step 2: re-configure with the REAL mock URL, flush, observe the
    // server got exactly one consent POST with the same Idempotency-Key.
    server.clearCaptured()
    Sammati.configure(tenantId: "tantu-pratha", baseURL: server.baseURL)

    do {
        try runAsync { await Sammati.flushOfflineQueue() }
    } catch {
        report.assert(false, "OfflineQueue: flush did not throw", "got: \(error)")
        return
    }

    let consentPosts = server.captured.filter { $0.method == "POST" && $0.path.hasSuffix("/consent") }
    report.assertEqual(consentPosts.count, 1, "OfflineQueue: server saw exactly ONE consent POST (replay collapsed)")
    if let post = consentPosts.first {
        let headerKey = post.headers["Idempotency-Key"] ?? post.headers["idempotency-key"]
        report.assertEqual(headerKey, key, "OfflineQueue: stable Idempotency-Key preserved across replay")
    }
    report.assertEqual(Sammati.queueDepth, 0, "OfflineQueue: depth=0 after successful flush")
}

// ─────────────────────────────────────────────────────────────────────────
// MARK: - Entrypoint
// ─────────────────────────────────────────────────────────────────────────

print("─── Sammati iOS SDK headless E2E driver — tenant: tantu-pratha ───")

resetSDKState()

let seenKeys = SeenKeys()
let server = MockHTTPServer(handler: makeMockHandler(seenKeys: seenKeys))
do {
    try server.start()
} catch {
    print("FATAL  could not start mock server: \(error)")
    exit(2)
}
print("Mock CDN listening on \(server.baseURL.absoluteString)")

let report = TestReport()

testFetchMobileConfig(report: report, server: server)
testLocaleResolver(report: report)
testConsentWriteForEachInteractionType(report: report, server: server, seenKeys: seenKeys)
testImpression(report: report, server: server)
testOfflineQueueCollapse(report: report, server: server, seenKeys: seenKeys)

server.stop()

print("")
print("\(report.pass) pass / \(report.fail) fail / \(report.total) total")

exit(report.fail == 0 ? 0 : 1)
