# HeadlessDriver — Sammati iOS SDK end-to-end smoke

`HeadlessDriver` is a macOS-only executable that boots a Foundation-only
mock CDN on an ephemeral TCP port and drives the Sammati iOS SDK through
its full happy-path + offline-replay flow. It exists so a developer (or
a customer-onboarding script) can validate the SDK end-to-end on a Mac
with **only Xcode Command-Line-Tools installed** — no full Xcode, no
iOS Simulator.

## Run it

```bash
cd packages/sdk-ios
swift run HeadlessDriver
```

Expected output ends with a one-line summary, e.g.:

```
33 pass / 0 fail / 33 total
```

Exit code is `0` iff every assertion passed, `1` otherwise (suitable for
CI gating).

## What it asserts

Driven against a customer-realistic `mobile-config` payload for tenant
`tantu-pratha`:

1. **`GET /v1/mobile-config/tantu-pratha`** decodes into `MobileConfig`
   with the expected shape, including all four `basis` values
   (`consent`, `legitimate_use`, `contractual`, `legal_obligation`).
2. **`LocaleResolver`** across an OS-locale matrix — Hindi, French
   (falls back via the chain), Marathi, explicit override wins, and
   the no-match case returns `nil` (never silent English).
3. **`postConsent`** for each interaction type (`accept_all`,
   `reject_all`, `save_preferences`) — asserts the wire body echoes
   `banner_version`, the `Idempotency-Key` header is present, and
   non-consent purposes (legitimate_use / contractual / legal_obligation)
   are forced ON in the choices map.
4. **`postImpression`** — asserts the body echoes `session_id`,
   `banner_shown`, `language`.
5. **Offline queue collapse** — enqueues two entries with identical
   canonical inputs, re-configures to the live mock URL, calls
   `Sammati.flushOfflineQueue()`, and asserts the server received
   **exactly one** consent POST with a stable `Idempotency-Key`.

## Why it lives in the SDK package

The driver imports `Sammati` with `@testable` so it can reach the
internal `RestClient` / `OfflineQueue` / `ConsentWriteBody` surface.
Debug builds of SwiftPM library targets compile with `-enable-testing`
by default, so `swift run HeadlessDriver` works out of the box from
Command-Line-Tools without any extra flags.

The HeadlessDriver target only compiles on macOS — UIKit / SwiftUI /
SafariServices banner code paths in the SDK are wrapped in
`#if canImport(UIKit)` and are not exercised by this driver. The
banner rendering surface is exercised by Xcode + Simulator integration
tests, which this driver does **not** replace.
