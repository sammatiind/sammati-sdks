// swift-tools-version:5.7
//
// MOB-01 — Sammati iOS SDK
//
// Minimum platform: iOS 14 (per PRD §11 NFR — banner first-paint < 300ms on
// iPhone 11). The choice of iOS 14 also aligns with App Attest availability
// for the optional FR-MOB-10 attestation gate (server-side enforcement
// lands in a follow-up).
//
// No external dependencies. URLSession + Keychain + UserDefaults are all we
// need; pulling in a networking library would bloat the binary past the
// 600KB ceiling in NFR §11 and require customers to also vend the transitive
// deps when they CocoaPod-install us.

import PackageDescription

let package = Package(
    name: "Sammati",
    defaultLocalization: "en",
    platforms: [
        // Bumped from iOS 14 → 15 because BannerSheetView.swift uses
        // SwiftUI .bordered / .borderedProminent button styles (iOS 15+).
        // iOS 14 is ~1% device share as of 2026; matches mobile-demo-ios.
        .iOS(.v15),
        // macOS minimum is purely so `swift test` runs on developer Macs,
        // and so the HeadlessDriver executable target below can be invoked
        // via `swift run HeadlessDriver` from a machine that has only the
        // Xcode Command-Line-Tools (no full Xcode install). The shipping
        // artifact is iOS-only — UIKit/SwiftUI banner code is wrapped in
        // `#if canImport(UIKit)` so the macOS build excludes it and
        // exercises only the cross-platform internals.
        .macOS(.v11),
    ],
    products: [
        .library(
            name: "Sammati",
            targets: ["Sammati"]
        ),
    ],
    dependencies: [],
    targets: [
        .target(
            name: "Sammati",
            dependencies: [],
            path: "Sources/Sammati"
        ),
        // MOB-01.TH — Headless end-to-end test harness.
        //
        // A macOS-only executable that boots a Foundation-only mock CDN on
        // an ephemeral port, drives the SDK through the full consent
        // happy-path + offline-replay flow, and prints a PASS/FAIL summary.
        // Intentionally NOT shipped to iOS — it's a developer tool that
        // lets us validate customer integrations (e.g. Tantu Pratha) end-
        // to-end without booting Xcode + a Simulator.
        .executableTarget(
            name: "HeadlessDriver",
            dependencies: ["Sammati"],
            path: "Sources/HeadlessDriver"
        ),
        .testTarget(
            name: "SammatiTests",
            dependencies: ["Sammati"],
            path: "Tests/SammatiTests"
        ),
    ]
)
